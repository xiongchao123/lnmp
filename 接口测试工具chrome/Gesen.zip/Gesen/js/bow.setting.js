bow.setting = {

    oauthUrl: "http://oauth-api.vip.vip.com",
    autoFetchTokenSecret: true,
    maxHistoryAmount: 300,

    getTokenUrl: function() {
        return this.oauthUrl + "/api/oauth/token/get";
    }
};


