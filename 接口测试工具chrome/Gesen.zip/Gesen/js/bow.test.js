

bow.testRunner = {

    testResults: [],
    testContext: {},

    runTest: function(statements, response) {
        if (!statements) {
            return;
        }

        this.before();
        var testResults = this.execute(statements, response);
        this.after();
        return testResults;
    },

    execute: function(statements, response) {
        var xhr = response.xhr;
        var responseText = xhr.responseText;

        var executionContext = {};
        executionContext.responseText = responseText;
        if (/^{/.test(responseText) || /^\[/.test(responseText)) {
            try {
                executionContext.responseBody = JSON.parse(responseText);
            }
            catch(e) {
                console.log(e);
            }
        }
        executionContext.assertEquals = this.assertEquals;
        executionContext.assertContains = this.assertContains;
        executionContext.assertTrue = this.assertTrue;
        executionContext.context = this.testContext;
        bow.testRunner.executionContext = executionContext;

        try {
            var func = new Function("executionContext", "with(executionContext) {" + statements + "}");
            func(executionContext);
        }
        catch (e) {
            console.dir(e);
            this.testResults.push({testName: "Evaluation Failed: " + e.message, result: false});
        }
        return this.testResults;
    },

    before: function() {
        bow.testRunner.executionContext = null;
        this.testResults = [];
    },

    after: function() {

    },

    beforeBatch: function() {
        bow.testRunner.testContext = {};
    },

    afterBatch: function() {

    },

    assertEquals: function(testName, responseText, expected) {
        var isEqual = expected == responseText ? true : false;

        var test = {};
        test.testName = testName;
        test.type = "assertEquals";
        test.result = isEqual;
        test.actual = responseText;
        test.expected = expected;

        if (!isEqual && responseText && expected) {
            responseText = "" + responseText;
            expected = "" + expected;
            var result = bow.testRunner.findFirstDifference(responseText, expected);
            var index1 = result.index1;
            var index2 = result.index2;
            if (index1 >= 0) {
                test.actual = responseText.substring(0, index1) + "<span class='diff'>" + responseText.substring(index1) + "</span>";
            }
            if (index2 >= 0) {
                test.expected = expected.substring(0, index2) + "<span class='diff'>" + expected.substring(index2) + "</span>";
            }
        }
        bow.testRunner.testResults.push(test);
    },

    assertContains: function(testName, responseText, str) {
        var contains = false;
        if (!responseText && !str) {
            contains = true;
        }
        else if (responseText == str) {
            contains = true;
        }
        else if (responseText.indexOf(str) >= 0) {
            contains = true;
        }

        var test = {};
        test.testName = testName;
        test.type= "assertContains";
        test.result = contains;
        test.actual = responseText;
        test.expected = str;
        bow.testRunner.testResults.push(test);
    },

    assertTrue: function(testName, expression) {
        var test = {};
        test.testName = testName;
        test.type= "assertTrue";
        // Expresion is already the evaluation result.
        test.result = expression;
        test.actual = bow.testRunner.executionContext.responseText;
        test.expected = "" + expression;
        bow.testRunner.testResults.push(test);
    },

    findFirstDifference: function(str1, str2) {
        var length1 = str1.length;
        var length2 = str2.length;
        var result = {};
        for (var i = 0; i < length1; i++) {
            var char1 = str1[i];
            if (i >= length2) {
                result.index1 = i;
                break;
            }
            else {
                var char2 = str2[i];
                if (char1 != char2) {
                    result.index2 = i;
                    break;
                }
            }
        }

        if (i < length2) {
            result.index2 = i;
        }
        return result;
    },
};


