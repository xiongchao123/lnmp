var bow = {};



