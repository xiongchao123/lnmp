bow.archer = {

    send: function(request) {
        this.validate(request);
        var url = bow.utils.encodeUrl(request.url);
        // var url = request.url;

        var xhr = new XMLHttpRequest();
        this.xhr = xhr;
        xhr.open(request.method, url, true);
        xhr.responseType = "text";

        var headers = this.getRequestHeaders(request);
        for (var i = 0; i < headers.length; i++) {
            xhr.setRequestHeader(headers[i].key, headers[i].value);
        }

        var body = this.getRequestBodyToBeSent(request);

        var deferred = $.Deferred();
        var response = {
            xhr: xhr, 
            start: new Date().getTime(),
            url: url,
        };
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                response.end = new Date().getTime();
                var status = xhr.status;
			    var isSuccess = status >= 200 && status < 300 || status === 304;
                if (isSuccess) {
                    deferred.resolve(response);
                }
                else {
                    deferred.reject(response);
                }
            }
        };
        
        if (body) {
            console.log(body);
            xhr.send(body);
        }
        else {
            xhr.send();
        }
        return deferred;
    },

    validate: function(request) {
        if (!request) {
            throw new Error("request must not be null");
        }

        if (!request.url) {
            throw new Error("request url must not be empty");
        }

        if (bow.utils.isMethodWithBody(request.method)) {
            if (!request.dataMode) {
                throw new Error("data mode must not be empty");
            }
        }
    },

    getRequestHeaders: function(request) {
        var headers = request.headers;
        if (headers == null) {
            headers = new Array();
        }

        headers.push({key: "Cache-Control", value: "no-cache"});
        if (request.dataMode === "urlencoded" || request.dataMode === "raw") {
            headers.push({key: "Content-Type", value: "application/x-www-form-urlencoded"});
        }
        
        return headers;
    },

    getRequestBodyToBeSent: function(request) {
        if (!bow.utils.isMethodWithBody(request.method)) {
            return null;
        }
        
        // if (request.dataMode === "raw") {
        //     return request.rawData;
        // }
        if (request.dataMode === "urlencoded" || request.dataMode === "raw") {
            var params = request.bodyParams;
            if (params && params.length > 0) {
                var buffer = new Array();
                for (var i = 0; i < params.length; i++) {
                    var key = encodeURIComponent(params[i].key);
                    var value = encodeURIComponent(params[i].value);
                    buffer.push(key + "=" + value);
                }
                return buffer.join("&");
            }
        }
        return null;
    },

    unpackResponseHeaders: function (data) {
        if (data === null || data === "") {
            return [];
        }

        var headers = [];
        var splits = data.split("\n");
        for (var i = 0; i < splits.length; i++) {
            var split = splits[i];
            var index = split.search(":");

            if (index !== -1) {
                var key = $.trim(split.substring(0, index));
                var value = $.trim(split.substring(index + 1));
                var header = {
                    "key": key,
                    "value": value,
                    "description": headerDetails[key.toLowerCase()]
                };
                headers.push(header);
            }
        }
        return headers;
    },
};


