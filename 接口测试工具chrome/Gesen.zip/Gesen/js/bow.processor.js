bow.processor = {};
bow.processor.mapiProcessor = {

    // Behavior related controls.
    signatureInUrl: false,
    enhanceTimestamp: true,
		
    prepareArrow: function(entity) {
        var meta = entity.meta;
        var key = bow.config.getApiKey(meta.apiKey);

        if (!key || !key.issuer) {
            return entity;
        }

        if (key.issuer === "oauth" && key.genre === "multi_app") {
            return this.prepareForMulti(entity);
        }
        else if (key.issuer === "oauth") {
            return this.prepareForOAuth(entity);
        }
        else if (key.issuer === "mi") {
            return this.prepareForLegacy(entity);
        }
    },

    prepareForOAuth: function(entity) {
        var arrow = JSON.parse(JSON.stringify(entity));
        var meta = arrow.meta;
        var request = arrow.request;        

        // Normalize request parameters.
        this.removeParamIfPresent(request, "api_sign");
        this.removeHeaderIfPresent(request, "Authorization");

        // Add timestamp to request url.
        if (this.enhanceTimestamp) {
            this.removeParamIfPresent(request, "timestamp");
            var timestamp = bow.utils.currentTimeSeconds();
            this.addUrlParam(request, "timestamp", timestamp);
        }

        var hash = this.makeSha1Hash(this.extractAllParamMap(request), meta.apiSecret, meta.tokenSecret);
        // Add signature to request parameter.
        if (this.signatureInUrl) {
            this.addUrlParam(request, "api_sign", hash);
        }
        // Add signature to request header.
        else {
            var headerValue = "OAuth " + "api_sign=" + hash;
            this.addHeader(request, "Authorization", headerValue);
        }

        return arrow;
    },

    prepareForMulti: function(entity) {
        var arrow = JSON.parse(JSON.stringify(entity));
        var meta = arrow.meta;
        var request = arrow.request;        

        // Normalize request parameters.
        this.removeParamIfPresent(request, "apiSign");
        this.removeHeaderIfPresent(request, "Authorization");

        // Add timestamp to request url.
        if (this.enhanceTimestamp) {
            this.removeParamIfPresent(request, "timestamp");
            var timestamp = bow.utils.currentTimeSeconds();
            this.addUrlParam(request, "timestamp", timestamp);
        }

        var hash = this.makeSha1Hash(this.extractAllParamMap(request), meta.apiSecret, meta.tokenSecret);
        // Add signature to request parameter.
        if (this.signatureInUrl) {
            this.addUrlParam(request, "apiSign", hash);
        }
        // Add signature to request header.
        else {
            var headerValue = "OAuth " + "apiSign=" + hash + ";api_sign=" + hash;
            this.addHeader(request, "Authorization", headerValue);
        }

        return arrow;
    },

    prepareForLegacy: function(entity) {
        var arrow = JSON.parse(JSON.stringify(entity));
        var meta = arrow.meta;
        var request = arrow.request;        

        // Normalize request parameters.
        this.removeParamIfPresent(request, "api_sign");

        // Add signature.
        var hash = this.makeMd5Hash(this.extractAllParamMap(request), meta.apiSecret);
        this.addUrlParam(request, "api_sign", hash);
        return arrow;
    },

    removeParamIfPresent: function(request, paramName) {
        var url = request.url;
        var urlParams = bow.utils.urlToParams(url);
        var urlPos = this.findParamPosition(urlParams, paramName);
        if (urlPos >= 0) {
            var newUrlParams = this.filterParams(urlParams, paramName);
            var newUrl = bow.utils.paramsToUrl(newUrlParams, url);
            request.url = newUrl;
        }

        var bodyParams = request.bodyParams;
        var bodyPos = this.findParamPosition(bodyParams, paramName);
        if (bodyPos >= 0 ) {
            var newBodyParams = this.filterParams(bodyParams, paramName);
            request.bodyParams = newBodyParams;
        }
    },

    removeHeaderIfPresent: function(request, headerName) {
        var headers = request.headers;
        var pos = this.findParamPosition(headers, headerName);
        if (pos >= 0) {
            var newHeaders = this.filterParams(headers, headerName);
            request.headers = newHeaders;
        }
    },

    addUrlParam: function(request, paramName, paramValue) {
        var url = request.url;
        if (url.indexOf("?") >= 0) {
            request.url =  url + "&" + paramName + "=" + paramValue;
        } 
        else {
            request.url = url + "?" + paramName + "=" + paramValue;
        }
    },

    addHeader: function(request, headerName, headerValue) {
        if (!request.headers) {
            request.headers = new Array();
        }
        request.headers.push({key: headerName, value: headerValue});
    },
    
    findParamPosition: function(params, paramName) {
        if (!params || params.length == 0) {
            return -1;
        }

        for (var i = 0; i < params.length; i++) {
            var param = params[i];
            if (param.key === paramName) {
                return i;
            }
        }
        return -1;
    },

    filterParams: function(params, paramName) {
        if (!params || params.length == 0) {
            return null;
        }

        var newParams = [];
        for (var i = 0; i < params.length; i++) {
            var param = params[i];
            if (paramName !== param.key) {
                newParams.push(param);
            }
        }
        return newParams;
    },

    makeSha1Hash: function(paramMap, apiSecret, tokenSecret) {
        if (!paramMap) {
            throw new Error("paramMap must not be null");
        }

        if (paramMap["api_sign"]) {
            delete paramMap["api_sign"];
        }

        var baseString = this.getBaseString(paramMap);
        if (!baseString) {
            throw new Error("baseString must not be empty");
        }

        var secret = apiSecret;
        if (tokenSecret) {
            secret = secret + "&" + tokenSecret;
        }

        var message = secret + baseString;
        var hash = CryptoJS.SHA1(message).toString(CryptoJS.enc.Hex);
        return hash;
    },

    makeMd5Hash: function(paramMap, secret) {
        if (!paramMap) {
            throw new Error("paramMap must not be null");
        }

        if (paramMap["api_sign"]) {
            delete paramMap["api_sign"];
        }

        var baseString = this.getBaseString(paramMap);
        if (!baseString) {
            throw new Error("baseString must not be empty");
        }

        var message = baseString + secret;
        var hash = CryptoJS.MD5(message).toString(CryptoJS.enc.Hex);
        return hash;
    },

    getBaseString: function(paramMap) {
        var keys = this.getSortedKeys(paramMap);
		var buffer = new Array();
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var value = decodeURIComponent(paramMap[key]);
            buffer.push(value);
        }
        return buffer.join("");
    },

    getSortedKeys: function(paramMap) {
        var keys = [];
        for (var key in paramMap) {
            if (paramMap.hasOwnProperty(key)) {
                keys.push(key);
            }
        }
        keys.sort();
        return keys;
    },

    extractAllParamMap: function(request) {
        var urlParams = bow.utils.urlToParams(request.url);
        var bodyParams = bow.utils.isMethodWithBody(request.method) ? request.bodyParams : null; 
        return bow.utils.getAllParamMap(urlParams, bodyParams);
    },
};

