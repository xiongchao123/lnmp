
bow.init = function() {

    bow.sidebarViewModel.init();
    bow.mainViewModel.init();
    bow.dao.init(function() {
        bow.sidebarViewModel.loadAllCollections();
    });
    
    ko.applyBindings(bow.sidebarViewModel, document.getElementById("sidebar-sections"));
    ko.applyBindings(bow.mainViewModel, document.querySelector(".gs-main"));
};

$(function() {
    bow.init();
});

bow.sidebarViewModel = {

    collections: ko.observableArray(),
    
    init: function() {
        this.bindEventListeners();
    },

    bindEventListeners: function() {
        var self = this;

        $(".gs-sidebar").jScrollPane({
            mouseWheelSpeed: 24,
            autoReinitialise: true,
        });

        $("#collection-items").on("click", ".sidebar-collection-head", function() {
            $(".sidebar-collection-head").removeClass("active");
            $(this).addClass("active")
            var collectionId = $(this).closest(".sidebar-collection").attr("id");
            bow.mainViewModel.loadCollectionRequests(collectionId);
        });
    },

    loadAllCollections: function() {
        var self = this;
        bow.dao.getAllCollections(function(collections) {
            self.collections(collections);
        });
    },

};

bow.mainViewModel = {

    collectionId: ko.observable(),
    requests: ko.observableArray(),
    progress: ko.observable(0),
    progressClass: ko.observable("progress-bar-success"),
    message: ko.observable(null),
    deferred: null,
    cancelled: false,

    clear: function() {
        $(".progress-bar").addClass("no-transition");

        this.progress(0);
        this.progressClass("progress-bar-success");
        this.message(null);
        this.deferred = null;
        this.cancelled = false;
        var requestViewModels = this.requests();
        if (requestViewModels && requestViewModels.length > 0) {
            for (var i = 0; i < requestViewModels.length; i++) {
                var requestViewModel = requestViewModels[i];
                requestViewModel.clear();
            }
        }

        // Trigger a reflow, flushing the CSS changes.
        $("#collection-progress")[0].offsetHeight;
        $(".progress-bar").removeClass("no-transition");
    },

    clearAll: function() {
        this.clear();
        this.collectionId(null);
        this.requests([]);
    },

    init: function() {
        this.bindEventListeners();
    },

    bindEventListeners: function() {
        var self = this;
        $("#run-tests").on("click", function() {
            self.launch();
        });

        $("#cancel-tests").on("click", function() {
            self.cancel();
        });

        $("#reset-tests").on("click", function() {
            self.clear();
        });

        $("#modal-test-result").modal({keyboard: true, show: false});
        $("#requests").on("click", ".response-test", function() {
            var testResult = ko.dataFor(this);
            $("#test-actual").html(testResult.actual);
            $("#test-expected").html(testResult.expected);
            $("#modal-test-result").modal("show");
        });

        $("#modal-response-payload").modal({keyboard: true, show: false});
        $("#requests").on("click", ".show-response", function() {
            var requestViewModel = ko.dataFor(this);
            var responseText = requestViewModel.getPrettyText();
            $("#response-payload").html(responseText);
            $("#modal-response-payload").modal("show");
        });
    },

    cancel: function() {
        this.cancelled = true;
    },

    launch: function() {
        var self = this;
        var collectionId = self.collectionId();
        if (!collectionId) {
            self.message("Please select a collection in the left sidebar before launching a test.");
            return;
        }

        $("#run-tests").button("loading");
        $("#reset-tests").attr("disabled", "disabled");
        self.clear();
        self.deferred = $.Deferred();
        self.deferred.done(function() {
            $("#run-tests").button("reset");
            $("#reset-tests").removeAttr("disabled");
        });

        bow.dao.getAllRequestsInCollection(collectionId, function(requests) {
            self.runTests(collectionId, requests);
        });
    },


    runTests: function(collectionId, requests) {
        if (!requests || requests.length == 0) {
            self.deferred.resolve();
            return;
        }

        var index = 0;
        var step = (1 / requests.length) * 100;
        bow.testRunner.beforeBatch();
        this.runTest(requests, index, step);
    },

    runTest: function(requests, i, step) {
        var self = this;
        var entity = requests[i];
        var arrow = bow.processor.mapiProcessor.prepareArrow(entity);
        var deferred = bow.archer.send(arrow.request);
        deferred.always(function(response) {
            var xhr = response.xhr;
            var id = entity.id;
            var status = xhr.status + " " + xhr.statusText;
            var responseTime = response.end - response.start;
            var contentType = xhr.getResponseHeader("Content-Type");
            contentType = contentType ? contentType : "";
            
            var requestViewModel = self.findRequestById(id);
            requestViewModel.httpStatus(status);
            requestViewModel.contentType(contentType);
            requestViewModel.responseTime(responseTime);
            requestViewModel.responseText(xhr.responseText);

            if (entity.test && entity.test.statements) {
                var statements = entity.test.statements;
                var testResults = bow.testRunner.runTest(statements, response);
                requestViewModel.testResults(testResults);

                if (self.hasTestError(testResults)) {
                    requestViewModel.testStatus(false);
                    if (self.progressClass() === "progress-bar-success") {
                        self.progressClass("progress-bar-danger");
                    }
                }
            }

            i++;
            if (self.cancelled || i >= requests.length) {
                self.deferred.resolve();
            }
            else {
                self.runTest(requests, i, step);
            }
            self.progress(self.progress() + step);
        });
    }, 

    findRequestById: function(requestId) {
        var requestViewModels = this.requests();
        if (requestViewModels) {
            for (var i = 0; i < requestViewModels.length; i++) {
                var requestViewModel = requestViewModels[i];
                if (requestViewModel.id === requestId) {
                    return requestViewModel;
                }
            }
        }
        return null;
    }, 

    hasTestError: function(testResults) {
        if (!testResults || testResults.length == 0) {
            return false;
        }

        for (var i = 0; i < testResults.length; i++) {
            var testResult = testResults[i];
            if (testResult.result == false) {
                return true;
            }
        }
        return false;
    },

    loadCollectionRequests: function(collectionId) {
        var self = this;
        self.clearAll();
        bow.dao.getAllRequestsInCollection(collectionId, function(requests) {
            self.collectionId(collectionId);
            var requestViewModels = [];
            if (requests && requests.length > 0) {
                for (var i = 0; i < requests.length; i++) {
                    var request = requests[i];
                    requestViewModels.push(new RequestViewModel(request));
                }
            }
            self.requests(requestViewModels);
        });
    },

    getProgressText: function() {
        var progress = this.progress();
        return progress ? progress + "%" : "0%";
    },

};

function RequestViewModel(entity) {
    this.id = entity.id;
    this.method = entity.request.method;
    this.url = entity.request.url;
    this.httpStatus = ko.observable();
    this.contentType = ko.observable();
    this.responseTime = ko.observable();
    this.responseText = ko.observable();
    this.testResults = ko.observableArray();
    this.testStatus = ko.observable(true);

    this.clear = function() {
        this.httpStatus(null);
        this.contentType(null);
        this.responseTime(null);
        this.responseText(null);
        this.testResults([]);
        this.testStatus(true);
    };

    this.getResponseTimeText = function() {
        var responseTime = this.responseTime();
        return responseTime ? responseTime + "ms" : null;
    };

    this.getTestStatusIcon = function() {
        var testStatus = this.testStatus();
        return testStatus ? "fa-smile-o" : "fa-frown-o";
    };

    this.getPrettyText = function() {
        var contentType = this.contentType();
        var responseText = this.responseText();
        var language = bow.utils.detectLanguage(contentType, responseText);
        var prettyText = null;
        if (responseText && responseText.length < 200000) {
            prettyText = bow.utils.beautify(language, responseText);
        }
        else {
            prettyText = responseText;
        }
        return prettyText;
    };
}
















