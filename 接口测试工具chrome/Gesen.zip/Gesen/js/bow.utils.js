
bow.utils = (function() {

    var methodsWithBody = ["POST", "PUT", "PATCH", "DELETE", "LINK", "UNLINK"];

    var isMethodWithBody = function(method) {
        if (isEmpty(method)) {
            return false;
        }

        method = method.toUpperCase();
        return $.inArray(method, methodsWithBody) >= 0;
    }; 

    var currentTimeSeconds = function() {
        var seconds = parseInt(new Date().getTime() / 1000);
        return seconds;
    };

    /**
     * Escape any string to be a valid JavaScript string literal, so that
     * it can be safely used in eval.
     * kudos to https://github.com/joliss/js-string-escape.
     */
    var escapeString = function(string) {
        return ('' + string).replace(/["'\\\n\r\u2028\u2029]/g, function (character) {
            // Escape all characters not included in SingleStringCharacters and
            // DoubleStringCharacters on
            // http://www.ecma-international.org/ecma-262/5.1/#sec-7.8.4
            switch (character) {
                case '"':
                case "'":
                case '\\':
                    return '\\' + character;
                // Four possible LineTerminator characters need to be escaped:
                case '\n':
                    return '\\n';
                case '\r':
                    return '\\r';
                case '\u2028':
                    return '\\u2028';
                case '\u2029':
                    return '\\u2029';
            }
        })
    };

    var escapeHtml = function(string) {
        if (!string) {
            return string;
        }
        return string
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    };

    var isEmpty = function(str) {
        return str ? false: true;
    };

    var urlToParamMap = function(url) {
        if (isEmpty(url)) {
            return null;
        }

        var index = url.indexOf("?");
        if (index === -1 || index === url.length - 1) {
            return null;
        }

        var query = url.substring(index + 1);
        var splits = query.split("&");
        var paramMap = {};
        for (var i = 0; i < splits.length; i++) {
        	var split = splits[i];
        	var eIndex = split.indexOf("=");
        	var key = null;
        	var value = null;
        	if (eIndex > 0) {
        		key = split.substring(0, eIndex);
        		value = split.substring(eIndex + 1);
        	}
        	else if (eIndex < 0) {
        		key = split;
        	}
        	paramMap[key] = value;
        }
        return paramMap;
    };

    var urlToParams = function(url) {
        if (isEmpty(url)) {
            return null;
        }

        var index = url.indexOf("?");
        if (index === -1 || index === url.length - 1) {
            return null;
        }

        var query = url.substring(index + 1);
        var splits = query.split("&");
        var params = [];
        for (var i = 0; i < splits.length; i++) {
        	var split = splits[i];
        	var eIndex = split.indexOf("=");
        	var key = null;
        	var value = null;
        	if (eIndex > 0) {
        		key = split.substring(0, eIndex);
        		value = split.substring(eIndex + 1);
        	}
        	else if (eIndex < 0) {
        		key = split;
        	}
        	
            var item = {"key": key, "value": value};
            params.push(item);
        }
        return params;
    };

    var paramsToUrl = function(params, url) {
        var baseUrl = getBaseUrl(url);
        if (!params || params.length == 0) {
            return baseUrl;
        }
        
        var buffer = new Array();
        for (var i = 0; i < params.length; i++) {
            var param = params[i];
            buffer.push(param.key + "=" + param.value);
        }

        var queryString = buffer.join("&");
        return baseUrl ? baseUrl + "?" +  queryString : queryString;
    };
    
    var encodeUrl = function (url) {
    	if (isEmpty(url)) {
    		return url;
    	}
    	
        var quesLocation = url.indexOf('?');
        if (quesLocation > 0) {
            var params = urlToParams(url);
            var baseUrl = getBaseUrl(url);
            var buffer = new Array();
            for (var i = 0; i < params.length; i++) {
                var key = encodeUrlParam(params[i].key);
                var value = encodeUrlParam(params[i].value); 
                buffer.push(key + "=" + value);
            }
            var newUrl = baseUrl + "?" + buffer.join("&");
            return newUrl;
        }
        else {
            return url;
        }
    };

    var encodeUrlParam = function(str) {
    	if (isEmpty(str)) {
    		return str;
    	}

        var decoded = decodeURIComponent(str);
        // Consider the string already encoded.
        if (decoded !== str) {
            return str;
        }

        var encoded = encodeURIComponent(str);
        return encoded;
    };

    var getBaseUrl = function(url) {
        if (isEmpty(url)) {
            return null;
        }

        var index = url.indexOf("?");
        if (index === 0) {
            return null;
        }
        else {
            return index < 0 ? url : url.substring(0, index);        
        }
    };

    var getAllParamMap = function(urlParams, bodyParams) {
        var paramMap = {};
        if (urlParams && urlParams.length > 0) {
            for (var i = 0; i < urlParams.length; i++) {
                paramMap[urlParams[i].key] = urlParams[i].value; 
            } 
        }

        if (bodyParams && bodyParams.length > 0) {
            for (i = 0; i < bodyParams.length; i++) {
                paramMap[bodyParams[i].key] = bodyParams[i].value; 
            } 
        }
        return paramMap;
    };

    var getAllParams = function(urlParams, bodyParams) {
        var params = new Array();
        if (urlParams && urlParams.length > 0) {
            for (var i = 0; i < urlParams.length; i++) {
                params.push({key: urlParams[i].key, value: urlParams[i].value});
            } 
        }

        if (bodyParams && bodyParams.length > 0) {
            for (i = 0; i < bodyParams.length; i++) {
                params.push({key: bodyParams[i].key, value: bodyParams[i].value});
            } 
        }
        return params;
    };

    var guid = function() {
        return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
            return v.toString(16);
        });
    };

    var limitStringLineWidth = function(string, numChars) {
        string = string.replace("&", "&amp;");
        var remainingChars = string;
        var finalString = "";
        var numLeft = string.length;
        do {        
            finalString += remainingChars.substr(0, numChars);
            remainingChars = remainingChars.substr(numChars);
            numLeft -= numChars;
            if (numLeft < 5) {
                numLeft -= numChars;
                finalString += remainingChars.substr(0, numChars)
            }
            else {
                finalString += "<br/>";
            }
        } while (numLeft > 0);

        return finalString;
    };

    var getShortUrl = function(url) {
        if (url.length > 80) {
            url = url.substring(0, 70) + "...";
        }
        url = limitStringLineWidth(url, 40);
        return url;
    };

    var detectLanguage = function(contentType, responseText) {
        // Guess according to response text.
        if (responseText) {
            if (/^{/.test(responseText) || /^\[/.test(responseText)) {
                return "javascript";
            }
        }

        if (bow.utils.isEmpty(contentType)) {
            return null;
        }

        if (contentType.search(/json/i) !== -1 || contentType.search(/javascript/i) !== -1) {
            return "javascript";
        }
        else if (contentType.search(/html/i) !== -1) {
            return "html";
        }
        else if (contentType.search(/xml/i) !== -1) {
            return "xml";
        }

        return null;
    };
    
    var beautify = function(language, text) {
        try {
            if (language === "javascript") {
                text = vkbeautify.json(text);
            }
            else if (language === "xml" || language == "html") {
                text = vkbeautify.xml(text); 
            }
        }
        catch (e) {
            console.log("beautify error " + e);
        }
        return text;
    };

    var detectPostBodyFormat = function(rawData) {
        var data = $.trim(rawData);
        if (!data) {
            return null;
        }
        
        var lines = data.split(/\r?\n/);
        if (lines.length == 0) {
            return null;
        }

        var line = lines[0];
        if (/\w+\s+\w+/.test(line)) {
            return "tabular";
        }
        else {
            return "url";
        }
    };

    var transformTextToParams = function(data) {
        var format = detectPostBodyFormat(data);
        if (format == "tabular") {
            return transformTabularTextToParams(data);
        }
        else if (format == "url") {
            return transformUrlTextToParams(data);
        }
        return null;
    };

    var transformTabularTextToParams = function(rawData) {
        var data = $.trim(rawData);
        if (!data) {
            return null;
        }
        
        var params = [];
        var lines = data.split(/\r?\n/);
        lines.forEach(function(line) {
            line = $.trim(line);
            if (line) {
                var param = {};
                var results = /(\w+)\s+(\w+.*)/.exec(line);
                if (results && results.length > 0) {
                    param.key = results[1];
                    param.value = results[2];
                }
                else {
                    param.key = line;
                }
                params.push(param);
            }
        });
        return params;
    };

    var transformUrlTextToParams = function(rawData) {
        var data = $.trim(rawData);
        if (!data) {
            return null;
        }

        var params = [];
        var splits = data.split("&");
        splits.forEach(function(split) {
            var param = {};
            var index = split.indexOf("=");
            if (index == -1) {
                param.key = split;
            }
            else {
                param.key = split.substring(0, index);
                param.value = split.substring(index + 1);
            }
            params.push(param);
        });
        return params;
    };

    var transformParamsToTabularText = function(params) {
        if (!params || params.length == 0) {
            return null;
        }

        var buffer = [];
        params.forEach(function(param) {
            var line = param.key;
            if (param.value) {
                line = line +  " " + param.value;
            }
            buffer.push(line);
        });
        var text = buffer.join("\n");
        return text;
    };

    var transformParamsToUrlText = function(params) {
        if (!params || params.length == 0) {
            return null;
        }

        var buffer = [];
        params.forEach(function(param) {
            var token = param.key;
            if (param.value) {
                token = token + "=" + param.value;
            }
            buffer.push(token);
        });
        var text = buffer.join("&");
        return text;
    };
    
    return {
        isMethodWithBody: isMethodWithBody,
        isEmpty: isEmpty,
        escapeString: escapeString,
        escapeHtml: escapeHtml,
        currentTimeSeconds: currentTimeSeconds,
        urlToParamMap: urlToParamMap,
        urlToParams: urlToParams,
        getAllParamMap: getAllParamMap,
        getAllParams: getAllParams,
        paramsToUrl: paramsToUrl,
        encodeUrl: encodeUrl,
        getBaseUrl: getBaseUrl,
        guid: guid,
        limitStringLineWidth: limitStringLineWidth,
        getShortUrl: getShortUrl,
        detectLanguage: detectLanguage,
        beautify: beautify,
        detectPostBodyFormat: detectPostBodyFormat,
        transformTextToParams: transformTextToParams,
        transformTabularTextToParams: transformTabularTextToParams,
        transformUrlTextToParams: transformUrlTextToParams,
        transformParamsToTabularText: transformParamsToTabularText,
        transformParamsToUrlText: transformParamsToUrlText
    };

})();

bow.equalUtils = (function() {

    var nullSafeEquals = function(object1, object2, callback) {
        if (!object1 && !object2) {
            return true;
        }
        else if (object1 && !object2) {
            return false;
        }
        else if (!object1 && object2) {
            return false;
        }
        return callback(object1, object2);
    };
    
    var paramsEquals = function(params1, params2) {
        return nullSafeEquals(params1, params2, function(params1, params2) {
            if (params1.length != params2.length) {
                return false;
            }
            for (var i = 0; i < params1.length; i++) {
                if (params1[i].key !== params2[i].key || params1[i].value !== params2[i].value) {
                    return false;
                }
            }
            return true;
        });
    };

    var requestEntityEquals = function(request1, request2) {
        return nullSafeEquals(request1, request2, function(request1, request2) {
            if (!metaEquals(request1.meta, request2.meta)) {
                return false;
            }
            if (!requestEquals(request1.request, request2.request)) {
                return false;
            }
            if (!testEquals(request1.test, request2.test)) {
                return false;
            }
            return true;
        });
    };

    var metaEquals = function(meta1, meta2) {
        return nullSafeEquals(meta1, meta2, function(meta1, meta2) {
                if (meta1.apiKey != meta2.apiKey) {
                    return false;
                }
                if (meta1.apiSecret != meta2.apiSecret) {
                    return false;
                }
                if (meta1.tokenId != meta2.tokenId) {
                    return false;
                }
                if (meta1.tokenSecret != meta2.tokenSecret) {
                    return false;
                }
                return true;
        });
    };

    var requestEquals = function(request1, request2) {
        return nullSafeEquals(request1, request2, function(request1, request2) {
            if (request1.url != request2.url) {
                return false;
            }
            if (request1.method != request2.method) {
                return false;
            }
            if (!paramsEquals(request1.bodyParams, request2.bodyParams)) {
                return false;
            }
            if (!paramsEquals(request1.headers, request2.headers)) {
                return false;
            }
            return true;
        });
    };

    var testEquals = function(test1, test2) {
        return nullSafeEquals(test1, test2, function(test1, test2) {
                if (test1.statements != test2.statements) {
                    return false;
                }
                return true;
        });
    };
    
    return {
        paramsEquals: paramsEquals,
        requestEntityEquals: requestEntityEquals,
    };
    
})();

