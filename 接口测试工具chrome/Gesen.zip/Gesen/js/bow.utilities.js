bow.init = function() {

    bow.sidebarViewModel.init();
    bow.hashViewModel.init();
    bow.signatureViewModel.init();
};

$(function() {
    bow.init();
});

bow.sidebarViewModel = {

    init: function() {
        this.bindEventListeners();
    },

    bindEventListeners: function() {
        var self = this;

        $("#toolbox").on("click", ".sidebar-tool-head", function() {
            $(".sidebar-tool-head").removeClass("active");
            $(this).addClass("active")

            $(".container").css("display", "none");

            var action = $(this).attr("data-action");
            var selector = "#" + action + "-container";
            $(selector).fadeIn();
        });
        
    },
};

bow.hashViewModel = {

    init: function() {
        this.bindEventListeners();
    },

    bindEventListeners: function() {
        var self = this;
        $("#btn-md5").on("click", function() {
            var text = $("#hash-text").val();
            var hash = CryptoJS.MD5(text).toString(CryptoJS.enc.Hex);
            $("#hash").val(hash);
        });

        $("#btn-sha1").on("click", function() {
            var text = $("#hash-text").val();
            var hash = CryptoJS.SHA1(text).toString(CryptoJS.enc.Hex);
            $("#hash").val(hash);
        });
    },
};

bow.signatureViewModel = {

    init: function() {
        this.bindEventListeners();
    },

    bindEventListeners: function() {
        var self = this;
        $("#btn-oauth").on("click", function() {
            self.generateOAuthSignature();
        });

        $("#btn-mi").on("click", function() {
            self.generateMiSignature();
        });
    },

    generateOAuthSignature: function() {
        var url = $("#signature-text").val();
        var paramMap = bow.utils.urlToParamMap(url);
        var baseString = bow.processor.mapiProcessor.getBaseString(paramMap);
        var secret = $("#signature-secret").val();
        var text = secret + baseString;
        var hash = CryptoJS.SHA1(text).toString(CryptoJS.enc.Hex);
        $("#signature").val(hash);
    },

    generateMiSignature: function() {
        var url = $("#signature-text").val();
        var paramMap = bow.utils.urlToParamMap(url);
        var baseString = bow.processor.mapiProcessor.getBaseString(paramMap);
        var secret = $("#signature-secret").val();
        var text = baseString + secret;
        var hash = CryptoJS.MD5(text).toString(CryptoJS.enc.Hex);
        $("#signature").val(hash);
    },
};
