
function RequestEntity() {

};

ko.bindingHandlers.keyValueEditor = {

    init: function(element, valueAccessor, allBindings, bindingContext) {
        var self = ko.bindingHandlers.keyValueEditor;
        var editorId = element.id;
        $(element).on("input", ".keyvalueeditor-key, .keyvalueeditor-value", function() {
            var params = self.getKeyValues(editorId);
            var observable = valueAccessor();
            observable(params);
        });

        $(element).on("click", ".keyvalueeditor-delete", function() {
            var params = self.getKeyValues(editorId);
            var observable = valueAccessor();
            observable(params);
        });
    },

    update: function(element, valueAccessor, allBindings, bindingContext) {
        var self = ko.bindingHandlers.keyValueEditor;
        var editorId = element.id;
        var newParams = ko.unwrap(valueAccessor());
        var params = self.getKeyValues(editorId);
        if (!bow.equalUtils.paramsEquals(newParams, params)) {
            $(element).keyvalueeditor("reset", newParams);
        }
    },

    getKeyValues: function(editorId) {
        var selector = "#" + editorId;
        var params = $(selector).keyvalueeditor("getValues");
        var newParams = [];
        for (var i = 0; i < params.length; i++) {
            var item = {
                key: params[i].key,
                value: params[i].value
            };
            newParams.push(item);
        }
        return newParams;
    },
};

ko.bindingHandlers.codeMirror = {

    init: function(element, valueAccessor, allBindings, viewModel, bindingContext) {
        var params = valueAccessor(); 
        var observable = params.data;
        var propertyName = params.propertyName ? params.propertyName : "codeMirror";
        var codeMirror = viewModel[propertyName];

        // Update model when value changes.
        codeMirror.on("blur", function() {
            var value = codeMirror.getValue();
            observable(value);
        });
    },

    update: function(element, valueAccessor, allBindings, viewModel, bindingContext) {
        var params = valueAccessor(); 
        var observable = params.data;
        var modeAccessor = params.mode;
        var propertyName = params.propertyName ? params.propertyName : "codeMirror";
        var codeMirror = viewModel[propertyName];
        
        var value = codeMirror.getValue();
        var data = observable();
        data = data ? data : "";
        // Prepare for update.
        if (value !== data) {
            var mode = _.isFunction(modeAccessor) ? modeAccessor.call(viewModel) : modeAccessor;
            if (mode) {
                var currentMode = codeMirror.getOption("mode");
                if (currentMode !== mode) {
                    codeMirror.setOption("mode", mode);
                }
            }
            codeMirror.setValue(data);
        }
    },
}; 

ko.bindingHandlers.rawEditor = {

    init: function(element, valueAccessor, allBindings, viewModel, bindingContext) {
        var self = ko.bindingHandlers.rawEditor;
        var params = valueAccessor(); 
        var observable = params.data;
        var propertyName = params.propertyName;
        var codeMirror = viewModel[propertyName];

        // Update model when value changes.
        codeMirror.on("blur", function() {
            var value = codeMirror.getValue();
            var newParams = bow.utils.transformTextToParams(value);
            var params = observable();
            if (!bow.equalUtils.paramsEquals(newParams, params)) {
                observable(newParams);
            }
        });
    },

    update: function(element, valueAccessor, allBindings, viewModel, bindingContext) {
        var self = ko.bindingHandlers.rawEditor;
        var params = valueAccessor(); 
        var observable = params.data;
        var propertyName = params.propertyName;
        var codeMirror = viewModel[propertyName];

        var value = codeMirror.getValue();
        var bodyParams = observable();
        var newValue = bow.utils.transformParamsToTabularText(bodyParams);
        if (value !== newValue) {
            codeMirror.setValue(newValue);
        }
    },
};

bow.init = function() {
    bow.requestViewModel.init();
    bow.responseViewModel.init();
    bow.meta.mapiViewModel.init();
    bow.testViewModel.init();
    bow.historyViewModel.init();
    bow.dao.init(function() {
        bow.historyViewModel.loadData();
    });

    ko.applyBindings(bow.meta.mapiViewModel, document.getElementById("request-helpers"));
    ko.applyBindings(bow.requestViewModel, document.getElementById("request"));
    ko.applyBindings(bow.responseViewModel, document.getElementById("response"));
    ko.applyBindings(bow.historyViewModel, document.getElementById("sidebar-sections"));
    ko.applyBindings(bow.historyViewModel, document.getElementById("modal-add-to-collection"));
};

$(function() {
    bow.init();
});

bow.meta = {};
bow.meta.mapiViewModel = {
		
	apiKey: ko.observable(),
	apiSecret: ko.observable(),
	tokenId: ko.observable(),
	tokenSecret: ko.observable(),

    toJS: function() {
        var o = {};
        o.apiKey = this.apiKey();
        o.apiSecret = this.apiSecret();
        o.tokenId = this.tokenId();
        o.tokenSecret = this.tokenSecret();
        o.type = "mapi";
        return o;
    },

    clear: function() {
        $("#request-helper-mapi-message").html("");
    },

    reload: function(meta) {
        this.apiKey(meta.apiKey);
        this.apiSecret(meta.apiSecret);
        this.tokenId(meta.tokenId);
        this.tokenSecret(meta.tokenSecret);
    },

    init: function() {
        var self = this;

        self.apiKey.subscribe(function(apiKey) {
            var key = bow.config.getApiKey(apiKey);
            var secret = key ? key.secret : "";
            self.apiSecret(secret);
        });

        bow.requestViewModel.url.subscribe(function(url) {
            // var paramMap = bow.utils.urlToParamMap(url);
            var paramMap = self.getAllParamMap();
            var key = null;
            if (paramMap && paramMap["api_key"]) {
                key = paramMap["api_key"];
            }
            else if (paramMap && paramMap["apiKey"]) {
                key = paramMap["apiKey"];
            }
            self.apiKey(key);

            var userToken = null;
            if (paramMap && paramMap["user_token"]) {
                userToken = paramMap["user_token"];
            }
            else if (paramMap && paramMap["userToken"]) {
                userToken = paramMap["userToken"];
            }
            self.tokenId(userToken);

            // Hack, force repaint, avoid displaying two request-actions bar.
            $("#request").hide().show(0);
        });

        bow.requestViewModel.bodyParams.subscribe(function(bodyParams) {
            var paramMap = self.getAllParamMap();
            var key = null;
            if (paramMap && paramMap["api_key"]) {
                key = paramMap["api_key"];
            }
            else if (paramMap && paramMap["apiKey"]) {
                key = paramMap["apiKey"];
            }
            self.apiKey(key);

            var userToken = null;
            if (paramMap && paramMap["user_token"]) {
                userToken = paramMap["user_token"];
            }
            else if (paramMap && paramMap["userToken"]) {
                userToken = paramMap["userToken"];
            }
            self.tokenId(userToken);

            // Hack, force repaint, avoid displaying two request-actions bar.
            $("#request").hide().show(0);
        });

        self.tokenId.subscribe(function(tokenId) {
            if (!bow.setting.autoFetchTokenSecret) {
                return;
            }

            if (bow.utils.isEmpty(tokenId) || tokenId.length < 40) {
                self.tokenSecret(null);
            }

            var url = bow.setting.getTokenUrl();
            $.get(url, {access_token: tokenId}, function(data) {
                var tokenSecret = null;
                if (data && data.code === 0 && data.result) {
                    tokenSecret = data.result.access_token_secret;
                }
                self.tokenSecret(tokenSecret);
            });
        });
    },

    validate: function() {
        $("#request-helper-mapi-message").html("");
        
        var paramMap = this.getAllParamMap();
        if (!paramMap["api_key"]) {
            return true;
        }

        try {
            var key = bow.config.getApiKey(paramMap["api_key"]);
            if (key.issuer === "oauth") {
                this.validateForOAuth(paramMap);
            }
            else if (key.issuer === "mi") {
                this.validateForLegacy(paramMap);
            }
            return true;
        }
        catch (e) {
            $("#request-helper-mapi-message").css("color", "red").html("<li>" + e.message + " </li>");
            return false;
        }
    },

    validateForOAuth: function(paramMap) {
        var config = this.getConfigForOAuth();
        var keyInUrl = paramMap["api_key"];
        if (config.apiKey != keyInUrl) {
            throw new Error("Config API key " + config.apiKey + " doesn't match with url API key " + keyInUrl);
        }

        if (!config.apiKey) {
            throw new Error("API key must not be empty");
        }

        if (!config.apiSecret) {
            throw new Error("API secret must not be empty");
        }

        if (paramMap["user_token"]) {
            var userToken = paramMap["user_token"]; 
            if (config.tokenId !== userToken) {
                throw new Error("Config tokenId " + config.tokenId + " doesn't match with url tokenId " + userToken);
            }
            
            if (!config.tokenId) {
                throw new Error("tokenId must not be empty");
            }

            if (!config.tokenSecret) {
                throw new Error("tokenSecret must not be null");
            }
        }
    },

    validateForLegacy: function(paramMap) {
        var config = this.getConfigForLegacy();
        var keyInUrl = paramMap["api_key"];
        if (config.apiKey != keyInUrl) {
            throw new Error("Config API key " + config.apiKey + " doesn't match with url API key " + keyInUrl);
        }

        if (!config.apiKey) {
            throw new Error("API key must not be empty");
        }

        if (!config.apiSecret) {
            throw new Error("API secret must not be empty");
        }
    },

    getConfigForOAuth: function() {
        var config = {};
        config.apiKey = this.apiKey();
        config.apiSecret = this.apiSecret();
        config.tokenId = this.tokenId();        
        config.tokenSecret = this.tokenSecret();
        return config;
    },

    getConfigForLegacy: function() {
        var config = {};
        config.apiKey = this.apiKey();
        config.apiSecret = this.apiSecret();
        return config;
    },
    
    getAllParamMap: function() {
        var urlParams = bow.requestViewModel.urlParams();
        var bodyParams = bow.requestViewModel.bodyParams();
        return bow.utils.getAllParamMap(urlParams, bodyParams);
    },

    getAllParams: function() {
        var urlParams = bow.requestViewModel.urlParams();
        var bodyParams = bow.requestViewModel.bodyParams();
        return bow.utils.getAllParams(urlParams, bodyParams);
    },

    getIssuer: function() {
        var apiKey = this.apiKey();
        var key = bow.config.getApiKey(apiKey);
        return key ? key.issuer : "";
    }
};

bow.testViewModel = {

    statements: ko.observable(),

    toJS: function() {
        var statements = this.statements();
        if (!statements) {
            return null;
        }

        var o = {};
        o.statements = statements;
        return o;
    },

    clear: function() {
        this.statements(null);
    },

    reload: function(test) {
        if (test && test.statements) {
            this.statements(test.statements);
        }
        else {
            this.statements(null);
        }
    },

    init: function() {
        this.bindEventListeners();
    },

    bindEventListeners: function() {
        var self = this;

        $("#write-tests").on("click", function() {
            if ($("#request-tests").css("display") === "block") {
                $("#request-tests").css("display", "none");
                $("#write-tests").removeClass("active");
            }
            else {
                $("#request-tests").css("display", "block");
                $("#write-tests").addClass("active");
                self.initOrRefreshTestEditor();
            }
        });

        $("#request-tests").on("click", ".test-snippet a", function() {
            var snippetId = $(this).attr("data-id");
            self.addSnippet(snippetId);
        });
    },

    initOrRefreshTestEditor: function() {
        var self = this;
        if (this.testEditor) {
            this.testEditor.refresh();
        }
        else {
            var testTextArea = document.getElementById("tests-textarea");
            this.testEditor = CodeMirror.fromTextArea(testTextArea, {
                mode: "javascript",
                theme: "eclipse",
                lineWrapping: false,
                lineNumbers: true,
                extraKeys: {"Enter": "newlineAndIndentContinueMarkdownList"}
            });

            this.testEditor.refresh();

            // Apply binding lazily.
            $("#tests-textarea").attr("data-bind", "codeMirror: {data: statements, propertyName: 'testEditor'}");
            ko.applyBindings(self, document.querySelector(".request-tests-editor-codemirror"));
        }
        this.testEditor.focus();
    },

    addSnippet: function(snippetId) {
        var line = this.getSnippet(snippetId);
        if (line) {
            var originalData = this.statements();
            var data = originalData ? originalData + "\n" + line : line;
            this.statements(data);
        }
    },

    getSnippet: function(id) {
        if (id === "snippet-text-equals") {
            return this.getTextEqualsSnippet();
        }
        else if (id === "snippet-text-contains") {
            return this.getTextContainsSnippet();
        }
        else if (id === "snippet-body-equals") {
            return this.getBodyEqualsSnippet();
        }
        else if (id === "snippet-expression") {
            return this.getExpressionSnippet();
        }
        else {
            return null;
        }
    },

    getTextEqualsSnippet: function() {
        var responseText = bow.responseViewModel.responseText();
        var text = responseText ? responseText : "response_body_string";
        var escaped = bow.utils.escapeString(text);
        return "assertEquals(\"Response text equals assertion\", responseText, \"" + escaped + "\");";
    },

    getTextContainsSnippet: function() {
        return "assertContains(\"Response text contains assertion\", responseText, \"string_you_want_to_search\");";
    },

    getBodyEqualsSnippet: function() {
        return "assertEquals(\"Response body assertion\", responseBody.propertyName, \"value\");";
    },

    getExpressionSnippet: function() {
        return "assertTrue(\"Expression assertion\", responseBody.propertyName == \"value\");";
    },
};


ko.components.register("request-test", {
    viewModel: {
        instance: bow.testViewModel,
    },
    template: {
        element: document.getElementById("request-test-template"),
    }, 
});


bow.requestViewModel = {

    url: ko.observable(),
    headers: ko.observable(),
    method: ko.observable("GET"),
    dataMode: ko.observable("urlencoded"),
    bodyParams: ko.observable(),

    // Display related controls, no need to serialize.
    requestId: ko.observable(),

    // Behavior related controls.
    enhanceRequest: true,

    toJS: function() {
        var o = {};
        o.url = this.url();
        o.headers = ko.toJS(this.headers);
        o.method = this.method();
        o.dataMode = this.dataMode();
        o.bodyParams = ko.toJS(this.bodyParams);
        return o;
    },

    clear: function() {
        this.url(null);
        this.headers(null);
        this.method("GET");
        this.dataMode("urlencoded");
        this.bodyParams(null);
        this.requestId(null);

        $("#request-preview").css("display", "none");
        $("#request-builder").css("display", "block");
        $("#request-helpers").css("display", "block");
        $("#preview-request").html("Preview");
        $("#update-request-in-collection").css("display", "none");
    },

    reload: function(requestEntity, fromCollection) {
        var request = requestEntity.request;
        this.url(request.url);
        this.headers(request.headers);
        this.method(request.method);
        this.dataMode(request.dataMode);
        this.bodyParams(request.bodyParams);

        this.requestId(requestEntity.id);

        $("#request-preview").css("display", "none");
        $("#request-builder").css("display", "block");
        $("#request-helpers").css("display", "block");
        $("#preview-request").html("Preview");

        var showSaveButton = fromCollection ? "inline-block" : "none";
        $("#update-request-in-collection").css("display", showSaveButton);
    },

    init: function() {
        this.initUI();
        this.bindObservables();
        this.bindEventListeners();
    },

    initUI: function() {
        this.initUrlParamEditor();
        this.initHeaderEditor();
        this.initUrlEncodedEditor();
    },

    initUrlParamEditor: function() {
        var options = {
            placeHolderKey: "URL Parameter Key",
            placeHolderValue: "Value",
            deleteButton: '<img class="deleteButton" src="img/delete.png">'
        };
        $("#url-keyvaleditor").keyvalueeditor("init", options);
    },

    initHeaderEditor: function() {
        var options = {
            placeHolderKey:"Header",
            placeHolderValue:"Value",
            deleteButton:'<img class="deleteButton" src="img/delete.png">'
        };
        $("#headers-keyvaleditor").keyvalueeditor("init", options);
    },

    initUrlEncodedEditor: function() {
        var options = {
            placeHolderKey:"Key",
            placeHolderValue:"Value",
            valueTypes:["text"],
            deleteButton:'<img class="deleteButton" src="img/delete.png">',
        };
        $("#urlencoded-keyvaleditor").keyvalueeditor("init", options);
    },

    bindObservables: function() {
        var self = this;

        self.urlParams = ko.computed({
            read: function() {
                var url = self.url();
                var params = bow.utils.urlToParams(url);
                return params;
            },
            write: function(params) {
                var url = self.url();
                var newUrl = bow.utils.paramsToUrl(params, url);
                self.url(newUrl);
            }
        });
    },
    
    bindEventListeners: function() {
        var self = this;

        $("#url-keyvaleditor-actions-open").on("click", function() {
            var isDisplayed = $("#url-keyvaleditor-container").css("display") === "block";
            if (isDisplayed) {
                $("#url-keyvaleditor-container").css("display", "none");
                $("#url-keyvaleditor-actions-open").removeClass("active");
            }
            else {
                $("#url-keyvaleditor-container").css("display", "block");
                $("#url-keyvaleditor-actions-open").addClass("active");
            }
        });

        $("#headers-keyvaleditor-actions-open").on("click", function() {
            var isDisplayed = $("#headers-keyvaleditor-container").css("display") === "block";
            if (isDisplayed) {
                $("#headers-keyvaleditor-container").css("display", "none");
                $("#headers-keyvaleditor-actions-open").removeClass("active");
            }
            else {
                $("#headers-keyvaleditor-container").css("display", "block");
                $("#headers-keyvaleditor-actions-open").addClass("active");
            }
        });

        $("#data-mode-selector .btn").on("click", function() {
            var mode = $(this).attr("data-mode");
            $("#body-editor-mode-selector").css("display", "none");
            if (mode == "urlencoded") {
                $("#urlencoded-keyvaleditor-container").css("display", "block");
                $("#body-data-container").css("display", "none");
                self.dataMode(mode);
            }
            else if (mode == "raw") {
                $("#urlencoded-keyvaleditor-container").css("display", "none");
                $("#body-data-container").css("display", "block");
                $("#body-editor-mode-selector").css("display", "block");
                self.dataMode(mode);
                self.initOrRefreshRawDataEditor();
            }
        });

        $("#body-editor-mode-selector .editor-mode").on("click", function() {
            var toFormat = $(this).attr("data-editor-mode");
            if (self.codeMirror) {
                var data = self.codeMirror.getValue();
                var dataFormat = bow.utils.detectPostBodyFormat(data);
                if (toFormat !== dataFormat) {
                    if (toFormat === "url") {
                        var params = bow.utils.transformTextToParams(data);
                        var urlText = bow.utils.transformParamsToUrlText(params);
                        self.codeMirror.setValue(urlText);
                    }
                    else if (toFormat === "tabular") {
                        var params = bow.utils.transformTextToParams(data);
                        var tabularText = bow.utils.transformParamsToTabularText(params);
                        self.codeMirror.setValue(tabularText);
                    }
                }
            }
        });

        $("#submit-request").on("click", function() {
            self.send();
        });

        $("#change-options").on("click", function() {
            if ($("#request-options").css("display") === "block") {
                $("#request-options").css("display", "none");
                $("#change-options").removeClass("active");
            }
            else {
                $("#request-options").css("display", "block");
                $("#change-options").addClass("active");
            }
        });

        $("#preview-request").on("click", function() {
            self.togglePreview();
        });

        $("#cancel-request").on("click", function() {
            self.cancel();
        });

        $("#request-actions-reset").on("click", function() {
            self.reset();
        });

        $("#update-request-in-collection").on("click", function() {
            var requestId = $("#request").attr("data-id");
            if (!requestId) {
                return;
            }
            bow.historyViewModel.updateCollectionRequest(requestId);
        });

        $(".request-option").on("click", function() {
            var name = $(this).attr("name");
            var checked = $(this).is(":checked");
            self.changeOption(name, checked);
        });
    },

    showRequestBody: function() {
        var method = this.method();
        return bow.utils.isMethodWithBody(method);
    },

    initOrRefreshRawDataEditor: function() {
        var self = this;
        if (this.codeMirror) {
            this.codeMirror.refresh();
        }
        else {
            var bodyTextArea = document.getElementById("body");
            this.codeMirror = CodeMirror.fromTextArea(bodyTextArea, {
                mode: "htmlmixed",
                lineNumbers: true,
                theme: "eclipse"
            });

            this.codeMirror.setSize("100%", 200);
            this.codeMirror.refresh();

            // Apply binding lazily.
            // $("#body").attr("data-bind", "codeMirror: {data: rawData}");
            $("#body").attr("data-bind", "rawEditor: {data: bodyParams, propertyName: 'codeMirror'}");
            ko.applyBindings(self, document.getElementById("body-data-container"));
        }
        this.codeMirror.focus();
    },

    changeOption: function(name, checked) {
        if (name === "no-request-enhancement") {
            this.enhanceRequest = checked ? false : true;
        }
        else if (name === "no-timestamp-enhancement") {
            bow.processor.mapiProcessor.enhanceTimestamp = checked ? false : true; 
        }
        else if (name === "add-signature-in-url") {
            bow.processor.mapiProcessor.signatureInUrl = checked;
        }
    },

    togglePreview: function() {
        if ($("#request-preview").css("display") === "block") {
            $("#preview-request").html("Preview");
            $("#request-preview").css("display", "none");
            $("#request-builder").css("display", "block");
            $("#request-helpers").css("display", "block");
        }
        else {
            this.ensureProperUrl();
            var valid = this.validate();
            if (!valid) {
                return;
            }
            
            this.buildPreview();
            $("#preview-request").html("Build");
            $("#request-builder").css("display", "none");
            $("#request-helpers").css("display", "none");
            $("#request-preview").css("display", "block");
        }
    },

    buildPreview: function() {
        var entity = this.createRequestEntity();
        var arrow = this.getArrow(entity);
        var request = arrow.request;

        var httpVersion = "HTTP/1.1";
        var method = request.method.toUpperCase();
        var url = request.url;
        url = bow.utils.encodeUrl(url);
        url = bow.utils.escapeHtml(url);
        var headers = bow.archer.getRequestHeaders(request);
        var body = bow.archer.getRequestBodyToBeSent(request);

        var requestPreview = method + " " + url + "<br/>";
        requestPreview += httpVersion + "<br/><br/>";

        if(body) {
            requestPreview += body + "<br/><br/>";
        }
        
        var headersCount = headers.length;
        for(var i = 0; i < headersCount; i ++) {
            requestPreview += headers[i].key + ": " + headers[i].value + "<br/>";
        }

        requestPreview += "<br/><br/>";
        $("#request-preview-content").html(requestPreview);
    },

    send: function() {
        this.ensureProperUrl();

        var valid = this.validate();
        if (!valid) {
            return;
        }

        var entity = this.createRequestEntity();
        var arrow = this.getArrow(entity);
        var deferred = bow.archer.send(arrow.request);

        // Update UI during sending.
        $("#submit-request").button("loading");
        bow.responseViewModel.showScreen("waiting");

        // Persist request.
        bow.historyViewModel.addHistoryRequest(entity);

        deferred.always(function(response) {
            $("#submit-request").button("reset");
            bow.responseViewModel.handleResponse(response);
        });
    },

    validate: function() {
        var url = this.url();
        if (!url) {
            return false;
        }

        if (this.enhanceRequest) {
            var valid = bow.meta.mapiViewModel.validate();
            return valid;
        }        
        else {
            return true;
        }
    },

    getArrow: function(entity) {
        if (this.enhanceRequest) {
            var arrow = bow.processor.mapiProcessor.prepareArrow(entity);
            return arrow;
        }
        else {
            return entity;            
        }
    },

    createRequestEntity: function() {
        var request = this.toJS();
        var meta = bow.meta.mapiViewModel.toJS();
        var test = bow.testViewModel.toJS();

        var url = request.url;
        if (!url) {
            return null;
        }

        var entity = new RequestEntity();
        entity.id = bow.utils.guid();
        entity.timestamp = new Date().getTime();
        entity.meta = meta;
        entity.request = request; 
        entity.test = test;
        return entity;
    },

    ensureProperUrl: function() {
        var url = this.url();
        var properUrl = $.trim(url);
        if (properUrl && properUrl.indexOf("http") != 0) {
            properUrl = "http://" + properUrl;
        }

        if (properUrl != url) {
            this.url(url);
        }
    },

    cancel: function() {
        var xhr = bow.archer.xhr;
        if (xhr !== null) {
            xhr.abort();
        }
        bow.responseViewModel.clear();
    },

    reset: function() {
        this.clear();
        bow.responseViewModel.clear();
        bow.meta.mapiViewModel.clear();
        bow.testViewModel.clear();
    },

    getHeaderCount: function() {
        var headers = this.headers();
        return headers ? headers.length : 0;
    },
};

bow.responseViewModel = {

    statusCode: ko.observable(),
    statusName: ko.observable(),
    responseTime: ko.observable(),
    responseText: ko.observable(),
    prettyText: ko.observable(),
    responseHeaders: ko.observable(),
    responseCookies: ko.observable(),
    language: ko.observable(),

    testResults: ko.observable(),

    clear: function() {
        this.statusCode(null);
        this.statusName(null);
        this.responseTime(null);
        this.responseText(null);
        this.prettyText(null);
        this.responseHeaders(null);
        this.responseCookies(null);
        this.language(null);

        $("#response").css("display", "none");
        $("#response-waiting-container").css("display", "none");
        $("#response-failed-container").css("display", "none");
        $("#response-success-container").css("display", "none");
    },

    init: function() {
        this.bindObservables();
        this.bindEventListeners();
    },

    bindObservables: function() {
        var self = this;
    },

    bindEventListeners: function() {
        var self = this;

        $("#response-body-toggle").tooltip();
        $("#response-body-line-wrapping").tooltip();
        $(".response-code").popover({
            trigger: "hover"
        });

        $(".response-tabs").on("click", "li", function() {
            var section = $(this).attr("data-section");
            self.showTab(section);
        });

        $("#response-formatting").on("click", "label", function() {
            var type = $("input", this).attr("data-type");
            self.showResponse(type);
        });

        $("#response-body-toggle").on("click", function() {
            if ($("#request").css("display") === "block") {
                $("#request-helpers").css("display", "none");
                $("#request").css("display", "none");
                $("#response-top-bar").css("display", "none");
                $(this).addClass("active");
            }
            else {
                $("#request-helpers").css("display", "block");
                $("#request").css("display", "block");
                $("#response-top-bar").css("display", "block");
                $(this).removeClass("active");
            }
        });

        $("#response-body-line-wrapping").on("click", function() {
            if (self.codeMirror) {
                var lineWrapping = self.codeMirror.getOption("lineWrapping");
                if (lineWrapping === true) {
                    $(this).removeClass("active");
                    self.codeMirror.setOption("lineWrapping", false);
                }
                else {
                    $(this).addClass("active");
                    self.codeMirror.setOption("lineWrapping", true);
                }
                self.codeMirror.refresh();
            } 
        });

        $("#response-language").on("click", "label", function() {
            if (self.codeMirror) {
                var mode = $("input", this).attr("data-mode");
                var currentMode = self.codeMirror.getOption("mode");
                if (mode !== currentMode) {
                    self.codeMirror.setOption("mode", mode);
                    self.codeMirror.refresh();
                }
            }            
        });

        $("#modal-test-result").modal({keyboard: true, show: false});
        $("#response-tests-container").on("click", ".response-test", function() {
            var testResult = ko.dataFor(this);
            $("#test-actual").html(testResult.actual);
            $("#test-expected").html(testResult.expected);
            $("#modal-test-result").modal("show");
        });
    },

    handleResponse: function(response) {
        var status = response.xhr.status;
        if (status == 0) {
            var actualUrl = response.url;
            $("#connection-error-url").html("<a href='" + actualUrl + "' target='_blank'>" + actualUrl + "</a>");
            this.showScreen("failed");
        }
        else {
            this.showScreen("success");
            // Show body tab.
            this.showTab("body");

            this.loadResponse(response);
        }
    },

    loadResponse: function(response) {
        var self = this;
        var xhr = response.xhr;
        var statusCode = xhr.status;
        var statusName = xhr.statusText; 
        var responseTime = response.end - response.start;

        // Response headers.
        var headers = bow.archer.unpackResponseHeaders(xhr.getAllResponseHeaders());
        headers = _.sortBy(headers, function(header) {
            return header.key;
        });

        // Response cookies.
        chrome.cookies.getAll({url: response.url}, function(cookies) {
            cookies = _.sortBy(cookies, function(cookie) {
                    return cookie.name;
            });
            self.responseCookies(cookies);
        });

        this.statusCode(statusCode);
        this.statusName(statusName);
        this.responseTime(responseTime);
        this.responseHeaders(headers);

        // Response payload.
        var contentType = xhr.getResponseHeader("Content-Type");
        contentType = contentType ? contentType : "";
        if (contentType.search(/image/i) >= 0) {
            this.loadImageResponse(response);
        }
        else {
            this.loadTextResponse(response, contentType);
        }

        // Execute test.
        var statements = bow.testViewModel.statements();
        var testResults = bow.testRunner.runTest(statements, response);
        this.testResults(testResults);

        this.updateUI(xhr);
    },

    loadImageResponse: function(response) {
        var url = response.url;
        $("#response-as-image").html("<img src='" + url + "'/>");
        this.showResponse("image");
    },

    loadTextResponse: function(response, contentType) {
        var xhr = response.xhr;
        var responseText = xhr.responseText;
        var language = bow.utils.detectLanguage(contentType, responseText);

        this.language(language);
        this.responseText(responseText);

        // Prevent too large payload which will lead the creation of plenty of dom nodes
        // and make the whole UI unusable.
        if (responseText && responseText.length > 200000) {
            this.prettyText(responseText);
        }
        else {
            var prettyText = bow.utils.beautify(language, responseText);
            this.prettyText(prettyText);
        }        
        this.showResponse("pretty");
    },

    /*
    detectLanguage: function(contentType, responseText) {
        // Guess according to response text.
        if (responseText) {
            if (/^{/.test(responseText) || /^\[/.test(responseText)) {
                return "javascript";
            }
        }

        if (bow.utils.isEmpty(contentType)) {
            return null;
        }

        if (contentType.search(/json/i) !== -1 || contentType.search(/javascript/i) !== -1) {
            return "javascript";
        }
        else if (contentType.search(/html/i) !== -1) {
            return "html";
        }
        else if (contentType.search(/xml/i) !== -1) {
            return "xml";
        }

        return null;
    },

    beautify: function(language, text) {
        try {
            if (language === "javascript") {
                text = vkbeautify.json(text);
            }
            else if (language === "xml" || language == "html") {
                text = vkbeautify.xml(text); 
            }
        }
        catch (e) {
            console.log("beautify error " + e);
        }
        return text;
    },
    */

    updateUI: function(xhr) {
        $(".response-header-name").popover({
            trigger: "hover",
        });
    },

    initOrRefreshResponseTextEditor: function() {
        var self = this;
        if (this.codeMirror) {
            this.codeMirror.refresh();
        }
        else {
            var codeDataArea = document.getElementById("code-data");
            this.codeMirror = CodeMirror.fromTextArea(codeDataArea, {
                mode: "javascript",
                lineNumbers: true,
                fixedGutter: true,
                onGutterClick: CodeMirror.newFoldFunction(CodeMirror.braceRangeFinder),
                theme: "eclipse",
                lineWrapping: true,
                readOnly: true
            });
            this.codeMirror.refresh();

            // Apply binding lazily.
            $("#code-data").attr("data-bind", "codeMirror: {data: prettyText, mode: getEditorMode}");
            ko.applyBindings(self, document.getElementById("response-as-pretty"));
        }
    },

    showScreen: function(screen) {
        $("#response").css("display", "block");
        var activeId = "#response-" + screen + "-container";
        var allIds = [
            "#response-waiting-container",
            "#response-failed-container",
            "#response-success-container"
        ];
        for (var i = 0; i < 3; i++) {
            $(allIds[i]).css("display", "none");
        }

        $(activeId).css("display", "block");
    },

    showTab: function(tabName) {
        $(".response-tabs li").removeClass("active");
        $(".response-container").css("display", "none");
        var tabSelector = '.response-tabs li[data-section="' + tabName + '"]';
        var tabContentSelector = '#response-' + tabName + '-container';
        $(tabSelector).addClass("active");
        $(tabContentSelector).css("display", "block");
    },

    showResponse: function(type) {
        $("#response-editors .response-editor").css("display", "none");
        $("#response-as-" + type).css("display", "block");
        $("#response-data-options").css("display", "block");
        $("#response-pretty-modifiers").css("display", "none");
        $("#response-formatting label").removeClass("active");

        if (type === "pretty") {
            this.initOrRefreshResponseTextEditor();
            $("#response-pretty-modifiers").css("display", "block");
            $("#response-formatting input[data-type='pretty']").closest("label").addClass("active");
        }
        else if (type === "raw") {
            $("#code-data-raw").val(this.responseText());
            $("#response-formatting input[data-type='raw']").closest("label").addClass("active");
        }
        else if (type === "image") {
            $("#response-data-options").css("display", "none");
        }
        else if (type === "preview") {

        }
    },

    changePreviewType: function (newType) {
        if (this.previewType === newType) {
            return;
        }

        this.previewType = newType;
        if (newType === "raw") {
            this.showResponse("text");
            $('#code-data-raw').val(this.responseText());
            $('#response-pretty-modifiers').css("display", "none");
        }
        else if (newType === "parsed") {
            this.showResponse("code");
            $('#response-pretty-modifiers').css("display", "block");
        }
        else if (newType === "preview") {
            this.showResponse("preview");
            $('#response-pretty-modifiers').css("display", "none");
        }
    },
    
    getEditorMode: function(language) {
        if (!language) {
            language = this.language();
        }

    	if (language === "javascript") {
    		return "javascript"
    	}
    	else if (language === "html" || language === "xml") {
    		return "xml";
    	}
    	else {
    		return null;
    	}
    },

    getHeaderName: function(key) {
        return key + " →";
    },

    getHeaderTitle: function() {
        var headers = this.responseHeaders();
        if (headers && headers.length > 0) {
            return "Headers (" + headers.length + ")";
        }
        return "Headers";
    },

    getResponseTime: function() {
        var time = this.responseTime();
        return time ? time + "ms" : "";
    },

    getStatusText: function() {
        var status = this.statusCode();
        var statusName = this.statusName();
        return status ? status + " " + statusName : "";
    },

    getStatusDescription: function() {
        var status = this.statusCode();
        if (status && status in httpStatusCodes) {
            var statusDescription = httpStatusCodes[status]["detail"];
            return statusDescription;
        }
        return "";
    },

    getStatusColor: function() {
        var status = this.statusCode();
		var isSuccess = status >= 200 && status < 300 || status === 304;
        return isSuccess ? "status-success" : "status-failed";
    },

    getCookieTitle: function() {
        var cookies = this.responseCookies();
        if (cookies && cookies.length > 0) {
            return "Cookies (" + cookies.length + ")";
        }
        return "Cookies";
    },

    getExpirationDate: function(cookie) {
        var expirationDate = cookie.expirationDate;
        if (expirationDate) {
            var date = new Date(expirationDate * 1000);
            return date.toUTCString();
        }
        return "";
    },

    getTestTitle: function() {
        var testResults = this.testResults();
        var count = 0; 
        var result = true;
        if (testResults && testResults.length > 0) {
            count = testResults.length;
            for (var i = 0; i < testResults.length; i++) {
                if (!testResults[i].result) {
                    result = false;
                    break;
                }
            }
        }

        var html = "";
        if (count > 0) {
            var icon = result ? "<i class='fa fa-lg fa-smile-o'></i>  " : "<i class='fa fa-lg fa-frown-o'></i>  ";
            html += icon;
        }
        html += "Test (" + count + ")";
        return html; 
    },
};

bow.historyViewModel = {

    historyRequests: ko.observableArray(),
    collections: ko.observableArray(),
    currentSection: "history",

    init: function() {
        this.bindObservables();
        this.bindEventListeners();
    },

    bindObservables: function() {
        var self = this;
        this.collectionSelections = ko.computed(function() {
            var collections = self.collections();
            var selections = [];
            var empty = {id: "", name: "Select"};
            selections.push(new CollectionViewModel(empty));
            if (collections && collections.length > 0) {
                for (var i = 0; i < collections.length; i++) {
                    selections.push(collections[i]);
                }
            }
            return selections;
        });
    },

    bindEventListeners: function() {
        var self = this;

        $(".gs-sidebar").jScrollPane({
            mouseWheelSpeed: 24,
            autoReinitialise: true,
        });

        $('.section-options a[rel="tooltip"]').tooltip();

        $("#sidebar-selectors li a").on("click", function() {
            var id = $(this).attr("data-id");
            self.select(id);
        });

        $("#sidebar-section-data").on("mouseenter", ".sidebar-request", function() {
            $(".request-actions", this).css("display", "block");
        });

        $("#sidebar-section-data").on("mouseleave", ".sidebar-request", function() {
            $(".request-actions", this).css("display", "none");
        });

        $("#sidebar-section-history").popover({
            selector: ".history-request",
            trigger: "hover",
            placement: "bottom",
            delay: {"show": 700},
            title: function() {
                return "History Request";
            },
            content: function() {
                var entity = ko.dataFor(this);
                return entity.request.url;
            },
        });

        $("#sidebar-section-collections").popover({
            selector: ".collection-request",
            trigger: "hover",
            placement: "bottom",
            delay: {"show": 700},
            title: function() {
                var name = $(this).attr("data-name");
                return name ? name : "Collection Request";
            },
            content: function() {
                var requestViewModel = ko.dataFor(this);
                return requestViewModel.url();
            },
        });
        
        $(".history-actions-delete").on("click", function() {
            self.clear();
        });
        
        $("#history-items").on("click", ".request-actions-delete", function() {
            var id = $(this).closest("li").attr("id");
            self.deleteHistoryRequest(id);
        });

        $("#history-items").on("click", ".request", function() {
            var id = $(this).closest("li").attr("id");
            self.loadHistoryRequest(id);
        });

        $("#collection-items").on("mouseenter", ".sidebar-collection-head", function() {
            $(".collection-head-actions", this).css("display", "block");
        });

        $("#collection-items").on("mouseleave", ".sidebar-collection-head", function() {
            $(".collection-head-actions", this).css("display", "none");
        });

        $("#collection-items").on("click", ".request", function() {
            var requestId = $(this).closest(".collection-request").attr("id");
            self.loadCollectionRequest(requestId);
        });

        $("#collection-items").on("click", ".collection-actions-edit", function() {
            var $parent = $(this).closest(".sidebar-collection");
            var id = $parent.attr("id");
            var name = $parent.attr("data-name");
            $("#form-edit-collection input[name=collection-id]").val(id);
            $("#form-edit-collection input[name=collection-original-name]").val(name);
            $("#form-edit-collection input[name=collection-name]").val(name);
            $("#modal-edit-collection").modal("show");
        });

        $("#collection-items").on("click", ".collection-actions-delete", function() {
            var $parent = $(this).closest(".sidebar-collection");
            var collectionId = $parent.attr("id");
            var name = $parent.attr("data-name");
            $("#modal-delete-collection-yes").attr("data-id", collectionId);
            $("#modal-delete-collection-name").html(name);
        });

        $("#collection-items").on("click", ".sidebar-collection-head-name", function() {
            var collectionId = $(this).closest(".sidebar-collection").attr("id");
            self.toggleRequestList(collectionId);
        });

        $("#collection-items").on("click", ".request-actions-edit", function() {
            var $parent = $(this).closest(".collection-request");
            var requestId = $parent.attr("id");
            var requestName = $parent.attr("data-name");
            $("#form-edit-collection-request .collection-request-id").val(requestId);
            $("#form-edit-collection-request .collection-request-original-name").val(requestName);
            $("#form-edit-collection-request .collection-request-name").val(requestName);
            $("#modal-edit-collection-request").modal("show");
        });

        $("#collection-items").on("click", ".request-actions-delete", function() {
            var requestId = $(this).closest(".collection-request").attr("id");
            $("#modal-delete-collection-request-yes").attr("data-id", requestId);
            $("#modal-delete-collection-request").modal("show");
        });

        $("#modal-new-collection").on("shown.bs.modal", function() {
            $("#new-collection-blank").focus();
        });

        $("#modal-edit-collection").on("shown.bs.modal", function() {
            $("#form-edit-collection input[name=collection-name]").focus();
        });

        $("#modal-add-to-collection").on("shown.bs.modal", function() {
            $("#modal-add-to-collection #new-collection").val("");
            $("#select-collection").focus();
        });

        $("#modal-edit-collection-request").on("shown.bs.modal", function() {
            $("#modal-edit-collection-request .collection-request-name").focus();
        });

        $("#modal-new-collection .btn-primary").on("click", function() {
            var name = $("#new-collection-blank").val();
            self.addCollection(name);
            $("#new-collection-blank").val("");
        });

        $("#modal-edit-collection .btn-primary").on("click", function () {
            var collectionId = $("#form-edit-collection input[name=collection-id]").val();
            var originalName = $("#form-edit-collection input[name=collection-original-name]").val();
            var name = $("#form-edit-collection input[name=collection-name]").val();
            if (originalName != name) {
                self.updateCollection(collectionId, name);
            }
        });

        $("#modal-delete-collection .btn-danger").on("click", function() {
            var collectionId = $("#modal-delete-collection-yes").attr("data-id");
            self.deleteCollection(collectionId);
        });

        $("#modal-add-to-collection .btn-primary").on("click", function () {
            var collectionId = $("#select-collection option:selected").val();
            var collectionName = $("#new-collection").val();
            var requestName = $("#new-request-name").val();

            // Add request to a new collection, need to create the collection on the fly.
            if (collectionName) {
                // Check if the named collection already exists.
                var collection = self.getCollectionByName(collectionName);
                if (collection) {
                    self.addRequestToCollection(collection.id, requestName);
                }
                // Really create the collection.
                else {
                    self.addCollection(collectionName, function(collection) {
                        self.addRequestToCollection(collection.id, requestName);
                    });
                }
            }
            // Add request to an existing collection.
            else if (collectionId) {
                self.addRequestToCollection(collectionId, requestName);
            }
        });

        $("#modal-edit-collection-request .btn-primary").on("click", function() {
            var requestId = $("#form-edit-collection-request .collection-request-id").val();
            var originalName = $("#form-edit-collection-request .collection-request-original-name").val();
            var requestName = $("#form-edit-collection-request .collection-request-name").val();
            if (originalName != requestName) {
                self.updateCollectionRequestName(requestId, requestName);
            }
        });

        $("#modal-delete-collection-request .btn-danger").on("click", function() {
            var requestId = $("#modal-delete-collection-request-yes").attr("data-id");
            self.deleteCollectionRequest(requestId);
        });
    },

    select: function(section) {
        if (this.currentSection == section) {
            return;
        }

        $("#sidebar-section-" + this.currentSection).css("display", "none");
        $("#" + this.currentSection + "-options").css("display", "none");

        $("#sidebar-section-" + section).fadeIn();
        $("#" + section + "-options").css("display", "block");

        this.currentSection = section;
    },

    clear: function() {
        var self = this;
        bow.dao.deleteAllHistoryRequests(function() {
            self.historyRequests([]);
        });
    },

    loadData: function() {
        this.loadAllHistoryRequests();
        this.loadAllCollections();
    },

    loadAllHistoryRequests: function() {
        var self = this;
        bow.dao.getAllHistoryRequests(function(requests) {
            if (!requests || requests.length == 0) {
                return;
            }
            self.historyRequests(requests);
        });
    },

    loadHistoryRequest: function(id) {
        bow.dao.getHistoryRequest(id, function(entity) {
            bow.responseViewModel.clear();
            bow.meta.mapiViewModel.reload(entity.meta);
            bow.requestViewModel.reload(entity);
            bow.testViewModel.reload(entity.test);
        });
    },

    addHistoryRequest: function(historyRequest) {
        var self = this;
        if (!historyRequest) {
            return null;
        }

        bow.dao.getLastHistoryRequest(function(lastRequest) {
            var equals = bow.equalUtils.requestEntityEquals(lastRequest, historyRequest);

            // Insert into history only when the current request is not the same as the last
            // history request.
            if (!equals) {
                var max = bow.setting.maxHistoryAmount;
                bow.dao.getHistoryRequestCount(function(count) {
                    if (count < max) {
                        bow.dao.addHistoryRequest(historyRequest, function(request) {
                            self.historyRequests.unshift(request);
                        });
                    }
                    // Delete the oldest history request to make room.
                    else {
                        bow.dao.deleteFirstHistoryRequest(function() {
                            self.historyRequests.pop();
                            bow.dao.addHistoryRequest(historyRequest, function(request) {
                                self.historyRequests.unshift(request);
                            });
                        });
                    }
                });
            }
        });
    },

    deleteHistoryRequest: function(id) {
        var self = this;
        bow.dao.deleteHistoryRequest(id, function(id) {
            self.historyRequests.remove(function(request) {
                return request.id === id;
            });
        });
    },

    loadCollectionRequest: function(requestId) {
        bow.dao.getCollectionRequest(requestId, function(entity) {
            bow.responseViewModel.clear();
            bow.meta.mapiViewModel.reload(entity.meta);
            bow.requestViewModel.reload(entity, true);
            bow.testViewModel.reload(entity.test);
        });
    },

    loadAllCollections: function() {
        var self = this;
        bow.dao.getAllCollections(function(collections) {
            if (!collections || collections.length == 0) {
                return;
            }
            var collectionViewModels = [];
            for (var i = 0; i < collections.length; i++) {
                var collection = collections[i];
                var collectionViewModel = new CollectionViewModel(collection);
                collectionViewModels.push(collectionViewModel);
            }
            self.collections(collectionViewModels);
        });
    },

    addCollection: function(name, callback) {
        var self = this;
        if (!name) {
            return;
        }

        var collection = new Object();
        collection.id = bow.utils.guid();
        collection.name = name;
        collection.timestamp = new Date().getTime();

        bow.dao.addCollection(collection, function(collection) {
            var collectionViewModel = new CollectionViewModel(collection);
            self.collections.unshift(collectionViewModel);
            if (callback) {
                callback(collection);
            }
        });
    },

    updateCollection: function(collectionId, name) {
        if (!collectionId || !name) {
            return;
        }

        var self = this;
        bow.dao.updateCollection(collectionId, name, function(updated) {
            var collectionViewModel = self.getCollectionById(updated.id);
            collectionViewModel.name(updated.name);
        });
    },

    deleteCollection: function(collectionId) {
        if (!collectionId) {
            return;
        }

        var self = this;
        bow.dao.deleteCollection(collectionId, function(collectionId) {
            self.collections.remove(function(collection) {
                return collection.id == collectionId;
            });
        });
    },

    addRequestToCollection: function(collectionId, requestName) {
        if (!collectionId) {
            return;
        }

        var entity = bow.requestViewModel.createRequestEntity();
        if (entity == null) {
            return;
        }

        var self = this;
        entity.name = requestName;
        entity.collectionId = collectionId;
        bow.dao.addCollectionRequest(entity, function(entity) {
            var collectionViewModel = self.getCollectionById(collectionId);
            collectionViewModel.requests.unshift(new CollectionRequestViewModel(entity));
        });
    },

    updateCollectionRequestName: function(requestId, requestName) {
        if (!requestId) {
            return;
        }

        var self = this;
        bow.dao.updateCollectionRequestName(requestId, requestName, function(entity) {
            var collectionId = self.findCollectionId(requestId);
            var collection = self.getCollectionById(collectionId);
            var requestViewModel = collection.getRequest(requestId);
            requestViewModel.name(requestName);
        });
    },

    updateCollectionRequest: function(requestId) {
        if (!requestId) {
            return;
        }

        var entity = bow.requestViewModel.createRequestEntity();
        if (entity == null) {
            return;
        }

        var self = this;
        bow.dao.updateCollectionRequest(requestId, entity, function(entity) {
            var collectionId = self.findCollectionId(requestId);
            var collection = self.getCollectionById(collectionId);
            var requestViewModel = collection.getRequest(requestId);
            requestViewModel.url(entity.request.url);
            requestViewModel.method(entity.request.method);
        });
    },

    toggleRequestList: function(collectionId) {
        if (!collectionId) {
            return;
        }

        var toggle = function() {
            var selector = "#" + collectionId + " .collection-requests"; 
            var $target = $(selector);
            if ($target.css("display") === "none") {
                $target.slideDown(100);
            }
            else {
                $target.slideUp(100);
            }
        };

        var collectionViewModel = ko.utils.arrayFirst(this.collections(), function(entry) {
            return entry.id == collectionId;
        });

        if (collectionViewModel.loaded) {
            toggle();
        }
        else {
            bow.dao.getAllRequestsInCollection(collectionId, function(requests) {
                collectionViewModel.loaded = true;
                var viewModels = [];
                if (requests && requests.length > 0) {
                    for (var i = 0; i < requests.length; i++) {
                        var entity = requests[i];
                        viewModels.push(new CollectionRequestViewModel(entity));
                    }
                }
                collectionViewModel.requests(viewModels);
                toggle();
            });
        }
    },

    deleteCollectionRequest: function(requestId) {
        if (!requestId) {
            return;
        }

        var self = this;
        bow.dao.deleteCollectionRequest(requestId, function(requestId) {
            var collectionId = self.findCollectionId(requestId);
            var collection = self.getCollectionById(collectionId);
            collection.deleteRequest(requestId);
        });        
    },

    findCollectionId: function(requestId) {
        var collectionId = $("#" + requestId).closest(".sidebar-collection").attr("id");
        return collectionId;
    },

    getCollectionById: function(collectionId) {
        var collection = ko.utils.arrayFirst(this.collections(), function(entry) {
            return entry.id == collectionId;
        });
        return collection;
    },

    getCollectionByName: function(collectionName) {
        var collection = ko.utils.arrayFirst(this.collections(), function(entry) {
            return entry.name() == collectionName;
        });
        return collection;
    },

    getShortUrl: function(url) {
        return bow.utils.getShortUrl(url);
    },
};

function CollectionViewModel(collection) {
    this.id = collection.id;
    this.name = ko.observable(collection.name);
    this.timestamp = collection.timestamp;
    this.loaded = false;
    this.requests = ko.observableArray();

    this.getRequest = function(requestId) {
        var requestViewModel = ko.utils.arrayFirst(this.requests(), function(entry) {
            return entry.id == requestId;
        });
        return requestViewModel;
    };

    this.deleteRequest = function(requestId) {
        this.requests.remove(function(entry) {
            return entry.id == requestId;
        });
    };
};

function CollectionRequestViewModel(requestEntity) {
    this.id = requestEntity.id;
    this.name = ko.observable(requestEntity.name);
    this.url = ko.observable(requestEntity.request.url);
    this.method = ko.observable(requestEntity.request.method);

    this.getDisplayName = function() {
        var displayName = "";
        var name = this.name();
        var url = this.url();
        if (name) {
            displayName = name;
        }
        else {
            displayName = url;
        }
        return bow.utils.getShortUrl(displayName);
    };
};










            






