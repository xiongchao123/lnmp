var indexedDB = window.indexedDB || window.webkitIndexedDB;

bow.dao = {

    onerror: function(e) {
        var error = e.target.error;
        console.log(error.name + ": " + error.message);
        console.dir(e);
    },

    init: function(callback) {
        var self = this;
        var version = 12;
        var request = indexedDB.open("gesen", version);
        request.onerror = self.onerror;

        request.onupgradeneeded = function(e) {
            console.log("running onupgradeneeded");

            var db = e.target.result;
            if(!db.objectStoreNames.contains("history_requests")) {
                var requestStore = db.createObjectStore("history_requests", {keyPath: "id"});
                requestStore.createIndex("timestamp", "timestamp", {unique: false});
            }

            if (!db.objectStoreNames.contains("collections")) {
                var collectionsStore = db.createObjectStore("collections", {keyPath: "id"});
                collectionsStore.createIndex("timestamp", "timestamp", {unique: false});
                collectionsStore.createIndex("name", "name", {unique: true});
            }

            if (!db.objectStoreNames.contains("collection_requests")) {
                var collectionRequestsStore = db.createObjectStore("collection_requests", {keyPath: "id"});
                collectionRequestsStore.createIndex("timestamp", "timestamp", { unique: false});
                collectionRequestsStore.createIndex("collectionId", "collectionId", {unique: false});
                collectionRequestsStore.createIndex("name", "name", {unique: false});
            }

            var collectionsStore = e.target.transaction.objectStore("collections");
            if (!self.hasIndex(collectionsStore, "name")) {
                collectionsStore.createIndex("name", "name", {unique: true});
            }

            var collectionRequestsStore = e.target.transaction.objectStore("collection_requests");
            if (!self.hasIndex(collectionRequestsStore, "name")) {
                collectionRequestsStore.createIndex("name", "name", {unique: false});
            }
        };

        request.onsuccess = function(e) {
            self.db = e.target.result;
            if (callback) {
                callback();
            }
        };
    },

    hasIndex: function(store, indexName) {
        var names = store.indexNames;
        for (var i = 0; i < names.length; i++) {
            var name = names[i];
            if (name == indexName) {
                return true;
            }
        }
        return false;
    },

    getAllHistoryRequests: function(callback) {
        var db = this.db;
        var historyRequests = [];
        var transaction = db.transaction(["history_requests"], "readonly");  
        var store = transaction.objectStore("history_requests");
        var index = store.index("timestamp");
        var range = IDBKeyRange.lowerBound(0);

        transaction.oncomplete = function(e) {
            callback(historyRequests);
        };
        
        var dbRequest = index.openCursor(range, "prev");
        dbRequest.onerror = function(e) {
            console.dir(e);
        };
        dbRequest.onsuccess = function(e) {
            var cursor = e.target.result;
            if (cursor) {
                var request = cursor.value;
                historyRequests.push(request);
                cursor.continue();
            }
        };
    },

    getHistoryRequest: function(id, callback) {
        var db = this.db;
        var transaction = db.transaction(["history_requests"], "readonly");
        var store = transaction.objectStore("history_requests");
        var dbRequest = store.get(id);
        dbRequest.onsuccess = function(e) {
            var request = e.target.result;
            if (request) {
                callback(request);
            }
        };
        dbRequest.onerror = function(e) {
            console.dir(e);
        };
    },

    deleteAllHistoryRequests: function(callback) {
        var db = this.db;
        var transaction = db.transaction(["history_requests"], "readwrite");
        var dbRequest = transaction.objectStore(["history_requests"]).clear();
        dbRequest.onsuccess = function(e) {
            callback();
        };
        dbRequest.onerror = function(e) {
            console.dir(e);
        };
    },

    deleteHistoryRequest: function(id, callback) {
        if (!id) {
            return;
        }

        var db = this.db;
        var transaction = db.transaction(["history_requests"], "readwrite");
        var store = transaction.objectStore(["history_requests"]);
        var dbRequest = store.delete(id)
        dbRequest.onsuccess = function(e) {
            callback(id);
        };
        dbRequest.onerror = function(e) {
            console.dir(e);
        };
    },

    /**
     * First is the oldest.
     * @param callback
     */
    deleteFirstHistoryRequest: function(callback) {
        var dao = this;
        this.getFirstHistoryRequest(function(firstRequest) {
            if (firstRequest) {
                dao.deleteHistoryRequest(firstRequest.id, callback);
            }
        });
    },

    getHistoryRequestCount: function(callback) {
        var db = this.db;
        var transaction = db.transaction(["history_requests"], "readonly");
        var store = transaction.objectStore("history_requests");
        store.count().onsuccess = function(e) {
            var count = e.target.result;
            callback(count);
        };
    },

    addHistoryRequest: function(request, callback) {
        if (!request) {
            return;
        }
        
        var db = this.db;
        var self = this;
        checkCount();

        function checkCount() {
            var max = bow.setting.maxHistoryAmount;
            self.getHistoryRequestCount(function(count) {
                if (count < max) {
                    insertRequest();
                }
            });
        };

        function insertRequest() {
            var transaction = db.transaction(["history_requests"], "readwrite");
            var store = transaction.objectStore("history_requests");
            var dbRequest = store.add(request);
            dbRequest.onsuccess = function(e) {
                callback(request);
            };
            dbRequest.onerror = function(e) {
                console.dir(e);
            };
        };
    },

    getFirstHistoryRequest: function(callback) {
        var db = this.db;
        var transaction = db.transaction(["history_requests"], "readonly");
        var store = transaction.objectStore("history_requests");
        var index = store.index("timestamp");
        var dbRequest = index.openCursor(null);
        dbRequest.onsuccess = function(e) {
            var cursor = e.target.result;
            var lastRequest = cursor ? cursor.value : null;
            callback(lastRequest);
        };
    },

    getLastHistoryRequest: function(callback) {
        var db = this.db;
        var transaction = db.transaction(["history_requests"], "readonly");
        var store = transaction.objectStore("history_requests");
        var index = store.index("timestamp");
        var dbRequest = index.openCursor(null, "prev");
        dbRequest.onsuccess = function(e) {
            var cursor = e.target.result;
            var lastRequest = cursor ? cursor.value : null;
            callback(lastRequest);
        };
    },

    getAllCollections: function(callback) {
        var db = this.db;
        var collections = [];
        var transaction = db.transaction(["collections"], "readonly");  
        var store = transaction.objectStore("collections");
        var index = store.index("name");

        transaction.oncomplete = function(e) {
            callback(collections);
        };

        var dbRequest = index.openCursor();
        dbRequest.onerror = self.onerror;
        dbRequest.onsuccess = function(e) {
            var cursor = e.target.result;
            if (cursor) {
                var collection = cursor.value;
                collections.push(collection);
                cursor.continue();
            }
        };
    },

    addCollection: function(collection, callback) {
        if (!collection) {
            return;
        }

        var db = this.db;
        var transaction = db.transaction(["collections"], "readwrite");
        var store = transaction.objectStore(["collections"]);
        var dbRequest = store.add(collection);
        dbRequest.onsuccess = function(e) {
            callback(collection);
        };
        dbRequest.onerror = function(e) {
            console.dir(e);
        };
    },

    updateCollection: function(collectionId, collectionName, callback) {
        if (!collectionId || !collectionName) {
            return;
        }

        var self = this;
        var db = this.db;
        this.getCollection(collectionId, function(collection) {
            collection.name = collectionName;
            var transaction = db.transaction(["collections"], "readwrite");
            var store = transaction.objectStore(["collections"]);
            var dbRequest = store.put(collection);
            dbRequest.onerror = self.onerror;
            dbRequest.onsuccess = function(e) {
                callback(collection);
            };
        });
    },

    getCollection: function(collectionId, callback) {
        if (!collectionId) {
            return;
        }

        var self = this;
        var db = this.db;
        var transaction = db.transaction(["collections"], "readonly");
        var store = transaction.objectStore(["collections"]);
        var dbRequest = store.get(collectionId);
        dbRequest.onerror = self.onerror;
        dbRequest.onsuccess = function(e) {
            var collection = e.target.result;
            callback(collection);
        };
    },

    deleteCollection: function(collectionId, callback) {
        if (!collectionId) {
            return;
        }

        var self = this;
        var db = this.db;
        var transaction = db.transaction(["collections"], "readwrite");
        var store = transaction.objectStore(["collections"]);
        var dbRequest = store.delete(collectionId);
        dbRequest.onerror = self.onerror;
        dbRequest.onsuccess = function() {
            self.deleteAllCollectionRequests(collectionId, function() {
                callback(collectionId);
            });
        }
    },

    deleteAllCollectionRequests: function(collectionId, callback) {
        if (!collectionId) {
            return;
        }

        var self = this;
        this.getAllRequestsInCollection(collectionId, function(requests) {
            if (requests && requests.length > 0) {
                for (var i = 0; i < requests.length; i++) {
                    var request = requests[i];
                    self.deleteCollectionRequest(request.id);
                }
            }
            if (callback) {
                callback();
            }
        });
    },

    deleteCollectionRequest: function(requestId, callback) {
        if (!requestId) {
            return;
        }

        var db = this.db;
        var transaction = db.transaction(["collection_requests"], "readwrite");
        var store = transaction.objectStore(["collection_requests"]);
        var dbRequest = store.delete(requestId);
        dbRequest.onerror = this.onerror;
        dbRequest.onsuccess = function() {
            if (callback) {
                callback(requestId);
            }
        };
    },

    getAllRequestsInCollection: function(collectionId, callback) {
        if (!collectionId) {
            return;
        }

        var self = this;
        var db = this.db;
        var requests = [];
        var transaction = db.transaction(["collection_requests"], "readonly");
        var store = transaction.objectStore(["collection_requests"]);
        var index = store.index("collectionId");
        var range = IDBKeyRange.only(collectionId);

        transaction.oncomplete = function(e) {
            // Sort descending by timestamp.
            if (requests && requests.length > 0) {
                requests.sort(function(request1, request2) {
                    return request2.timestamp - request1.timestamp;
                });
            }
            callback(requests);
        };
        
        var dbRequest = index.openCursor(range);
        dbRequest.onerror = self.onerror;
        dbRequest.onsuccess = function(e) {
            var cursor = e.target.result;
            if (cursor) {
                var request = cursor.value;
                requests.push(request);
                cursor.continue();
            }
        };
    },

    addCollectionRequest: function(requestEntity, callback) {
        if (!requestEntity || requestEntity.request == null || !requestEntity.request.url) {
            return;
        }

        var db = this.db;
        var transaction = db.transaction(["collection_requests"], "readwrite");
        var store = transaction.objectStore(["collection_requests"]);
        var dbRequest = store.add(requestEntity);
        dbRequest.onerror = this.onerror;
        dbRequest.onsuccess = function() {
            if (callback) {
                callback(requestEntity);
            }
        };
    },

    updateCollectionRequestName: function(requestId, requestName, callback) {
        if (!requestId) {
            return;
        }

        var self = this;
        var db = this.db;
        this.getCollectionRequest(requestId, function(requestEntity) {
            requestEntity.name = requestName;
            var transaction = db.transaction(["collection_requests"], "readwrite");
            var store = transaction.objectStore(["collection_requests"]);
            var dbRequest = store.put(requestEntity);
            dbRequest.onerror = self.onerror;
            dbRequest.onsuccess = function(e) {
                var func = callback != null ? callback : ($.isFunction(requestName) ? requestName : null);
                if (func) {
                    func(requestEntity);
                }
            };
        });
    },

    /**
     * Only request, meta and test are updated, other properties are kept unchanged.
     */
    updateCollectionRequest: function(requestId, requestEntity, callback) {
        if (!requestId) {
            return;
        }

        var self = this;
        var db = this.db;
        this.getCollectionRequest(requestId, function(entity) {
            entity.request = requestEntity.request;
            entity.meta = requestEntity.meta;
            entity.test = requestEntity.test;
            var transaction = db.transaction(["collection_requests"], "readwrite");
            var store = transaction.objectStore(["collection_requests"]);
            var dbRequest = store.put(entity);
            dbRequest.onerror = self.onerror;
            dbRequest.onsuccess = function(e) {
                var func = callback != null ? callback : ($.isFunction(request) ? request : null);
                if (func) {
                    func(entity);
                }
            };
        });
    },

    getCollectionRequest: function(requestId, callback) {
        if (!requestId) {
            return;
        }

        var db = this.db;
        var transaction = db.transaction(["collection_requests"], "readonly");
        var store = transaction.objectStore(["collection_requests"]);
        var dbRequest = store.get(requestId);
        dbRequest.onerror = this.onerror;
        dbRequest.onsuccess = function(e) {
            var request = e.target.result;
            callback(request);
        }
    },
};

