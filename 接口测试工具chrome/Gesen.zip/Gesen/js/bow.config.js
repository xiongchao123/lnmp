function ApiKey(key, secret, issuer, description, genre) {
    this.key = key;
    this.secret = secret;
    this.issuer = issuer;
    this.description = description;
    this.genre = genre;
}

bow.config = {

    apiKeyMap: {
        "247abb702bc5b9cac62d2cd9b0f10fa8": new ApiKey("247abb702bc5b9cac62d2cd9b0f10fa8", "73a0177f97622aa1c1c55788e17d62dd", "mi", "shop_android"), 
        "bcfd4f09b5c7de4262dafd1022607f76": new ApiKey("bcfd4f09b5c7de4262dafd1022607f76", "d08bdcb7c8f635d2c0a690c51c83e1b7", "mi", "shop_android_new"), 
        "24415b921531551cb2ba756b885ce783": new ApiKey("24415b921531551cb2ba756b885ce783", "022932c38af2f98ad4a2722371de72bd", "mi", "shop_iphone"), 
        "04e0dd9c76902b1bfc5c7b3bb4b1db92": new ApiKey("04e0dd9c76902b1bfc5c7b3bb4b1db92", "90cbc38f8e5d589bf6109219bfa70d0f", "mi", "shop_ipad"), 
        "007b4af4727d99f1539bf2980f9aa922": new ApiKey("007b4af4727d99f1539bf2980f9aa922", "cbffa4c30926b8f87a296f693588c433", "mi", "shop_wap"), 
        "209fb0e5b68ebbea81d597c97b7cbed7": new ApiKey("209fb0e5b68ebbea81d597c97b7cbed7", "9275bf277728545b07a35223dae0b680", "mi", "mapi"), 
        "5a1aa3cc337f05f152ea6828ad102ebc": new ApiKey("5a1aa3cc337f05f152ea6828ad102ebc", "2f99f908a3c5d75eacccb58ac5093fae", "mi", "shop_ipad"), 
        "10e47f11a02d6172a074d7a520bdd9a1": new ApiKey("10e47f11a02d6172a074d7a520bdd9a1", "2a3e26c83bf59ada696f22b35c51b8a2", "mi", "goods.api"), 
        "27b5859b171703ef28ceab1e7b9bd05b": new ApiKey("27b5859b171703ef28ceab1e7b9bd05b", "c32d3a6406c0dcab7b23b0a77fb15874", "mi", "weixin"), 
        "8113a8307d134bbba2d56db0415feefd": new ApiKey("8113a8307d134bbba2d56db0415feefd", "05f021c158234e648b069142683f391b", "oauth", "club_wap"), 
        "8cec5243ade04ed3a02c5972bcda0d3f": new ApiKey("8cec5243ade04ed3a02c5972bcda0d3f", "d97f3d38280d4c64a55c48a8f589907a", "oauth", "shop_wap"), 
        "34a65f18bae9439589ae5f889bc37075": new ApiKey("34a65f18bae9439589ae5f889bc37075", "d2802c4ee8fe4ba48a39b7818f1d2917", "oauth", "shop_iphone"), 
        "23e7f28019e8407b98b84cd05b5aef2c": new ApiKey("23e7f28019e8407b98b84cd05b5aef2c", "f36fb86c3941475e81a7ae08340b261e", "oauth", "shop_android"), 
        "55bc59b3dfd8460aaeb9efed5d45e968": new ApiKey("55bc59b3dfd8460aaeb9efed5d45e968", "257d1b2780f9400989d9512765ef4f4c", "oauth", "shop_ipad"), 
        "4549aa1b0fac4aed83085fc50e2a7d28": new ApiKey("4549aa1b0fac4aed83085fc50e2a7d28", "684d6c7b6fa14fddb9cffc9ba23d6f75", "oauth", "shop_android_pad"), 
        "bb31b77daf2640df8f69c3d449d19669": new ApiKey("bb31b77daf2640df8f69c3d449d19669", "d2319ee158c848769f075f1fc8110924", "oauth", "bi"), 
        "66623a464e8545ccba8b0c4609fc95ae": new ApiKey("66623a464e8545ccba8b0c4609fc95ae", "38ef9d6618174b228d8924e6fbbd4508", "oauth", "stunner_android"),
        "731cf1e19f4d4ed9b94ec8f7e55eced7": new ApiKey("731cf1e19f4d4ed9b94ec8f7e55eced7", "c0be1496baf74d24b26d78b68ee94004", "oauth", "stunner_iphone"),
        "08ca328f54964c74a914868e34e1df24": new ApiKey("08ca328f54964c74a914868e34e1df24", "f51d40fce7cf4c0082e226a2bcf85382", "oauth", "stunner_ipad"),
        "bcdb8ec168fc439981a80c6b05f2c9e0": new ApiKey("bcdb8ec168fc439981a80c6b05f2c9e0", "b2f6b251a0b443b693bfd4c363cb4e61", "oauth", "dian_android"),
        "54041553d4fc46feb601c6d248848a7b": new ApiKey("54041553d4fc46feb601c6d248848a7b", "4f363d102d3c4c24b7fb1482df8ad848", "oauth", "dian_iphone"),
        "d0a812cb3cef4dffa7eb5f25d05b8954": new ApiKey("d0a812cb3cef4dffa7eb5f25d05b8954", "00ef07d16d9e435d8784c1ff88dbd17b", "oauth", "dian_ipad"),
        "002164d4a9c74c9791c94633314a124c": new ApiKey("002164d4a9c74c9791c94633314a124c", "722f5fc4845a4cb09aa9062cb18b79e1", "oauth", "hitao_iphone", "multi_app"),
        "5f94ac3596754ed18f78d110aa2ffb71": new ApiKey("5f94ac3596754ed18f78d110aa2ffb71", "9e037abbc76e4cd495a0a871ad1ebcc2", "oauth", "hitao_android", "multi_app"),
        "21e3cb3ef2a9482aad8fec12328032df": new ApiKey("21e3cb3ef2a9482aad8fec12328032df", "cdd1d6f0bc2d4582a11a73067a676771", "oauth", "hitao_ipad", "multi_app"),
        "1d71e5aab77e4a84ac43a2cbcecc7682": new ApiKey("1d71e5aab77e4a84ac43a2cbcecc7682", "615edb9eb26e404cb30c6de4a7f38095", "oauth", "kids_iphone", "multi_app"),
        "55d4deb1da4647cbb18cbac8180b1739": new ApiKey("55d4deb1da4647cbb18cbac8180b1739", "fa45b2b01a2e42918593e9d8461b7c60", "oauth", "kids_android", "multi_app"),
        "0c22f9330fb14d93b64d827b4c92242d": new ApiKey("0c22f9330fb14d93b64d827b4c92242d", "ec0aa8fa2f36499eb04ad0e7e49fb666", "oauth", "kids", "multi_app"),
        "94dfab02f68647bdbc490227a298c686": new ApiKey("94dfab02f68647bdbc490227a298c686", "83d98caf96d94de1aa1ffb8d55d43e79", "oauth", "match_iphone", "multi_app"),
        "67e9a94a467c459bb30ecc193677ce41": new ApiKey("67e9a94a467c459bb30ecc193677ce41", "66b82c42c399494aa9429f1da7d4fd62", "oauth", "match_android", "multi_app"),
        "616df486d5334f4d8df8e9a4a7490082": new ApiKey("616df486d5334f4d8df8e9a4a7490082", "4b8512ad7481409c9831cdf528822d5b", "oauth", "cosmetics_iphone", "multi_app"),
        "ca7b95d65fe4438b824d13783185364a": new ApiKey("ca7b95d65fe4438b824d13783185364a", "b08f93f4d70e4f33a89d93ea8a2f0ac5", "oauth", "cosmetics_android", "multi_app"),
        "f612a68e01194a17b1a4f3ed0e4dd923": new ApiKey("f612a68e01194a17b1a4f3ed0e4dd923", "4198c6b75f36417cacdd5cd2b77cebec", "oauth", "kids_test", "multi_app"), 
        "e0fd7d3a03078e4ba85cbb61fba5cb366b54a7ae": new ApiKey("e0fd7d3a03078e4ba85cbb61fba5cb366b54a7ae", "2dc87a6b14d9123d48a5212a34c2c3fe82888d7a", "oauth", "kids_theirs", "multi_app")
    },

    getApiKey: function(key) {
        var apiKey = this.apiKeyMap[key];
        return apiKey;
    }
};




